import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import MemberOffice from "./pages/MemberOffice";
import AdminOffice from "./pages/AdminOffice";
import ApplicationConfirmation from "./pages/ApplicationConfirmation";
import PersonalizeAccess from "./pages/PersonalizeAccess";
import DemoLogin from "./pages/DemoLogin";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/pedido/confirmacao"} component={ApplicationConfirmation} />
      <Route path={"/personalizar"} component={PersonalizeAccess} />
      <Route path={"/acesso"} component={DemoLogin} />
      <Route path={"/membros"} component={MemberOffice} />
      <Route path={"/membros/:section"} component={MemberOffice} />
      <Route path={"/admin"} component={AdminOffice} />
      <Route path={"/admin/:section"} component={AdminOffice} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
