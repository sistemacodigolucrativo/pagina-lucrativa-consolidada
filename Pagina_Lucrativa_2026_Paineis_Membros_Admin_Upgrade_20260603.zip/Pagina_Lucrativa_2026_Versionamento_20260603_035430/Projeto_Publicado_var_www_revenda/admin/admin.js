const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);
const BASE_PATH = window.location.pathname.startsWith('/revenda') ? '/revenda' : '';
const appUrl = (path) => `${BASE_PATH}${path}`;
let csrfToken = '';
let adminOrdersCache = [];
let adminResellersCache = [];
let adminCheckoutCache = null;

const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#039;',
}[char]));

const message = (selector, text, ok = true) => {
  const el = $(selector);
  if (!el) return;
  el.textContent = text;
  el.className = `form-message ${ok ? 'success' : 'error'}`;
};

const postJson = async (url, payload = {}) => {
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
    },
    body: JSON.stringify(payload),
  });
  const data = await response.json();
  if (!response.ok || !data.ok) throw new Error(data.error || 'Erro inesperado.');
  return data;
};

const adminTabLabels = {
  overview: 'Dashboard',
  orders: 'Pedidos',
  resellers: 'Usuários',
  checkout: 'Pagamento PIX',
  'manual-key': 'Gerar chave manual',
  'global-texts': 'Textos globais',
};

const adminPanels = {
  overview: '#adminOverviewPanel',
  orders: '#ordersPanel',
  resellers: '#resellersPanel',
  checkout: '#checkoutPanel',
  'manual-key': '#manualKeyPanel',
  'global-texts': '#globalTextsPanel',
};

const setAdminMenuOpen = (open) => {
  const menu = $('#adminSideMenu');
  const toggle = $('#adminMenuToggle');
  const backdrop = $('#adminMenuBackdrop');
  menu?.classList.toggle('is-open', open);
  menu?.setAttribute('aria-hidden', String(!open));
  toggle?.setAttribute('aria-expanded', String(open));
  if (backdrop) backdrop.hidden = !open;
};

const showAdminTab = (tab = 'overview') => {
  const safeTab = adminPanels[tab] ? tab : 'overview';
  Object.entries(adminPanels).forEach(([key, selector]) => {
    $(selector)?.classList.toggle('hidden', key !== safeTab);
  });
  $$('[data-tab]').forEach((button) => {
    button.classList.toggle('active', button.dataset.tab === safeTab);
  });
  const currentView = $('#adminCurrentView');
  if (currentView) currentView.textContent = adminTabLabels[safeTab] || safeTab;
};

const showDashboard = async () => {
  $('#loginBox').classList.add('hidden');
  $('#dashboardBox').classList.remove('hidden');
  showAdminTab('overview');
  await Promise.all([loadOrders(), loadResellers(), loadCheckoutSettings(), loadGlobalTexts()]);
};


const setAdminText = (selector, value) => {
  const element = $(selector);
  if (element) element.textContent = value;
};

const renderAdminOverview = () => {
  const pendingOrders = adminOrdersCache.filter((order) => String(order.status_pagamento || '').toLowerCase() === 'pendente').length;
  const activeUsers = adminResellersCache.filter((reseller) => String(reseller.status || '').toLowerCase() === 'ativo').length;
  const publishedPages = adminResellersCache.filter((reseller) => String(reseller.slug || '').trim()).length;
  const checkoutPixReady = Boolean(adminCheckoutCache && String(adminCheckoutCache.pix_key || '').trim());

  setAdminText('#adminKpiPendingOrders', pendingOrders);
  setAdminText('#adminKpiActiveUsers', activeUsers);
  setAdminText('#adminKpiPublishedPages', publishedPages);
  setAdminText('#adminKpiCheckoutPix', checkoutPixReady ? 'OK' : 'Pendente');

  const health = [];
  health.push(checkoutPixReady ? 'PIX principal configurado.' : 'PIX principal ainda não configurado.');
  health.push(pendingOrders ? `${pendingOrders} pedido(s) aguardando conferência.` : 'Nenhum pedido pendente no momento.');
  health.push(activeUsers ? `${activeUsers} membro(s) ativo(s).` : 'Nenhum membro ativo encontrado.');
  health.push(publishedPages ? `${publishedPages} página(s) com link público.` : 'Nenhuma página com slug configurado.');

  const healthList = $('#adminHealthList');
  if (healthList) {
    healthList.innerHTML = health.map((item) => `<li>${escapeHtml(item)}</li>`).join('');
  }
};

const loadOrders = async () => {
  const response = await fetch(appUrl('/api/admin.php?action=orders'));
  if (!response.ok) return;
  const data = await response.json();
  if (!data.ok) return;
  adminOrdersCache = Array.isArray(data.orders) ? data.orders : [];
  renderAdminOverview();
  $('#ordersList').innerHTML = adminOrdersCache.map((order) => `
    <article class="admin-row">
      <header>
        <div>
          <h3>${escapeHtml(order.nome)}</h3>
          <p>${escapeHtml(order.email)} · ${escapeHtml(order.whatsapp || '')}</p>
        </div>
        <span class="badge">${escapeHtml(order.status_pagamento)}</span>
      </header>
      <p>ID transação: ${escapeHtml(order.transaction_id || 'não informado')}</p>
      <p>Enviado em: ${escapeHtml(order.criado_em)}</p>
      ${order.comprovante ? `<a class="muted-link" href="${appUrl(`/api/admin.php?action=receipt&id=${order.id}`)}" target="_blank" rel="noreferrer">Abrir comprovante no painel</a>` : '<p>Sem comprovante anexado.</p>'}
      <div class="actions">
        <button class="button primary small" type="button" data-approve="${order.id}">Aprovar pagamento</button>
        <button class="button ghost small" type="button" data-generate-order="${order.id}" data-email="${escapeHtml(order.email)}" data-name="${escapeHtml(order.nome)}" data-whatsapp="${escapeHtml(order.whatsapp || '')}">Gerar chave</button>
        <button class="button danger small" type="button" data-reject="${order.id}">Recusar</button>
      </div>
    </article>
  `).join('') || '<p>Nenhum pedido encontrado.</p>';
};

const loadResellers = async () => {
  const response = await fetch(appUrl('/api/admin.php?action=resellers'));
  if (!response.ok) return;
  const data = await response.json();
  if (!data.ok) return;
  adminResellersCache = Array.isArray(data.resellers) ? data.resellers : [];
  renderAdminOverview();
  $('#resellersList').innerHTML = adminResellersCache.map((reseller) => {
    const link = reseller.slug ? `${data.origin}/p/${reseller.slug}` : '';
    return `
      <article class="admin-row">
        <header>
          <div>
            <h3>${escapeHtml(reseller.nome)}</h3>
            <p>${escapeHtml(reseller.email)} · ${escapeHtml(reseller.whatsapp || '')}</p>
          </div>
          <span class="badge">${escapeHtml(reseller.status)}</span>
        </header>
        <p>Chave: <strong>${escapeHtml(reseller.chave_acesso || 'não gerada')}</strong></p>
        <p>Template: ${escapeHtml(reseller.template_escolhido)}</p>
        <p>PIX: ${escapeHtml(reseller.pix_tipo || '')} ${escapeHtml(reseller.pix_chave || '')}</p>
        <p>Recebedor: ${escapeHtml(reseller.pix_recebedor || 'não informado')}</p>
        ${link ? `<a class="muted-link" href="${escapeHtml(link)}" target="_blank" rel="noreferrer">${escapeHtml(link)}</a>` : '<p>Sem slug definido.</p>'}
        <div class="actions">
          <button class="button ghost small" type="button" data-edit="${reseller.id}" data-name="${escapeHtml(reseller.nome)}" data-email="${escapeHtml(reseller.email)}" data-whatsapp="${escapeHtml(reseller.whatsapp || '')}" data-slug="${escapeHtml(reseller.slug || '')}" data-current-status="${escapeHtml(reseller.status)}">Editar</button>
          <button class="button ghost small" type="button" data-generate-user="${reseller.id}">Gerar nova chave</button>
          <button class="button primary small" type="button" data-status="ativo" data-id="${reseller.id}">Ativar</button>
          <button class="button warning small" type="button" data-status="suspenso" data-id="${reseller.id}">Suspender</button>
          <button class="button danger small" type="button" data-status="banido" data-id="${reseller.id}">Banir</button>
        </div>
      </article>
    `;
  }).join('') || '<p>Nenhum dono de página encontrado.</p>';
};

const loadCheckoutSettings = async () => {
  const response = await fetch(appUrl('/api/admin.php?action=checkout_settings'));
  if (!response.ok) return;
  const data = await response.json();
  if (!data.ok || !data.checkout) return;
  adminCheckoutCache = data.checkout;
  renderAdminOverview();
  const form = $('#checkoutSettingsForm');
  if (!form) return;
  form.elements.title.value = data.checkout.title || '';
  form.elements.price.value = data.checkout.price || '';
  form.elements.pix_type.value = data.checkout.pix_type || '';
  form.elements.pix_key.value = data.checkout.pix_key || '';
  form.elements.pix_receiver.value = data.checkout.pix_receiver || '';
  form.elements.pix_instructions.value = data.checkout.pix_instructions || '';
  form.elements.note.value = data.checkout.note || '';
};

const renderGlobalTexts = (sections) => {
  const container = $('#globalTextsFields');
  if (!container) return;

  container.innerHTML = sections.map((section) => `
    <section class="global-text-section">
      <h3>${escapeHtml(section.title)}</h3>
      <div class="global-text-section__grid">
        ${(section.fields || []).map((field) => {
          const value = escapeHtml(field.value || '');
          const label = escapeHtml(field.label || field.key);
          const name = escapeHtml(field.key);
          if (field.type === 'textarea') {
            return `
              <label class="full-field">
                ${label}
                <textarea name="${name}" maxlength="2000" rows="4">${value}</textarea>
              </label>
            `;
          }
          return `
            <label>
              ${label}
              <input name="${name}" maxlength="500" value="${value}">
            </label>
          `;
        }).join('')}
      </div>
    </section>
  `).join('');
};

const loadGlobalTexts = async () => {
  const response = await fetch(appUrl('/api/admin.php?action=global_texts'));
  if (!response.ok) return;
  const data = await response.json();
  if (!data.ok || !Array.isArray(data.sections)) return;
  renderGlobalTexts(data.sections);
};

$('#loginForm')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  message('#loginMessage', 'Entrando...');
  try {
    const data = await postJson(appUrl('/api/admin.php?action=login'), {
      usuario: form.usuario.value,
      senha: form.senha.value,
    });
    csrfToken = data.csrf || '';
    await showDashboard();
  } catch (error) {
    message('#loginMessage', error.message, false);
  }
});

$('#logoutBtn')?.addEventListener('click', async () => {
  await fetch(appUrl('/api/admin.php?action=logout'));
  location.reload();
});

$('#adminMenuToggle')?.addEventListener('click', () => setAdminMenuOpen(true));
$('#adminMenuClose')?.addEventListener('click', () => setAdminMenuOpen(false));
$('#adminMenuBackdrop')?.addEventListener('click', () => setAdminMenuOpen(false));

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') setAdminMenuOpen(false);
});

document.addEventListener('click', async (event) => {
  const target = event.target;
  if (!(target instanceof HTMLElement)) return;

  if (target.dataset.tab) {
    showAdminTab(target.dataset.tab);
    setAdminMenuOpen(false);
  }

  if (target.dataset.approve) {
    await postJson(appUrl('/api/admin.php?action=approve_order'), { id: Number(target.dataset.approve) });
    await Promise.all([loadOrders(), loadResellers()]);
  }

  if (target.dataset.reject) {
    const observacao_admin = prompt('Motivo da recusa:') || '';
    await postJson(appUrl('/api/admin.php?action=reject_order'), { id: Number(target.dataset.reject), observacao_admin });
    await loadOrders();
  }

  if (target.dataset.generateOrder) {
    const data = await postJson(appUrl('/api/admin.php?action=generate_key'), {
      email: target.dataset.email,
      nome: target.dataset.name,
      whatsapp: target.dataset.whatsapp,
    });
    alert(`Chave gerada: ${data.chave}`);
    await Promise.all([loadOrders(), loadResellers()]);
  }

  if (target.dataset.generateUser) {
    const data = await postJson(appUrl('/api/admin.php?action=generate_key'), {
      id: Number(target.dataset.generateUser),
    });
    alert(`Nova chave gerada: ${data.chave}`);
    await loadResellers();
  }

  if (target.dataset.edit) {
    const nome = prompt('Nome:', target.dataset.name || '') || target.dataset.name || '';
    const email = prompt('E-mail:', target.dataset.email || '') || target.dataset.email || '';
    const whatsapp = prompt('WhatsApp:', target.dataset.whatsapp || '') || target.dataset.whatsapp || '';
    const slug = prompt('Slug:', target.dataset.slug || '') || target.dataset.slug || '';
    const status = prompt('Status: ativo, pendente, suspenso ou banido', target.dataset.currentStatus || 'pendente') || target.dataset.currentStatus || 'pendente';
    await postJson(appUrl('/api/admin.php?action=update_reseller'), {
      id: Number(target.dataset.edit),
      nome,
      email,
      whatsapp,
      slug,
      status,
    });
    await loadResellers();
  }

  if (target.dataset.status && target.dataset.id) {
    const motivo = ['suspenso', 'banido'].includes(target.dataset.status) ? (prompt('Motivo:') || '') : '';
    await postJson(appUrl('/api/admin.php?action=update_reseller_status'), {
      id: Number(target.dataset.id),
      status: target.dataset.status,
      motivo,
    });
    await loadResellers();
  }
});

$('#refreshAdminOverviewBtn')?.addEventListener('click', async () => {
  message('#globalTextsMessage', '');
  await Promise.all([loadOrders(), loadResellers(), loadCheckoutSettings()]);
});

$('#reloadGlobalTextsBtn')?.addEventListener('click', async () => {
  message('#globalTextsMessage', 'Recarregando textos...');
  await loadGlobalTexts();
  message('#globalTextsMessage', 'Textos recarregados.');
});

$('#globalTextsForm')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const values = Object.fromEntries(new FormData(form).entries());
  message('#globalTextsMessage', 'Salvando textos globais...');
  try {
    const data = await postJson(appUrl('/api/admin.php?action=save_global_texts'), { values });
    renderGlobalTexts(data.sections || []);
    message('#globalTextsMessage', 'Textos globais salvos.');
  } catch (error) {
    message('#globalTextsMessage', error.message, false);
  }
});

$('#checkoutSettingsForm')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  message('#checkoutSettingsMessage', 'Salvando pagamento PIX...');
  try {
    await postJson(appUrl('/api/admin.php?action=save_checkout_settings'), {
      title: form.elements.title.value,
      price: form.elements.price.value,
      pix_type: form.elements.pix_type.value,
      pix_key: form.elements.pix_key.value,
      pix_receiver: form.elements.pix_receiver.value,
      pix_instructions: form.elements.pix_instructions.value,
      note: form.elements.note.value,
    });
    message('#checkoutSettingsMessage', 'Pagamento PIX salvo.');
  } catch (error) {
    message('#checkoutSettingsMessage', error.message, false);
  }
});

$('#manualKeyForm')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  message('#manualKeyMessage', 'Gerando chave...');
  try {
    const data = await postJson(appUrl('/api/admin.php?action=generate_key'), {
      nome: form.elements.nome.value,
      email: form.elements.email.value,
      whatsapp: form.elements.whatsapp.value,
    });
    message('#manualKeyMessage', `Chave gerada: ${data.chave}`);
    form.reset();
    await loadResellers();
  } catch (error) {
    message('#manualKeyMessage', error.message, false);
  }
});

fetch(appUrl('/api/admin.php?action=me')).then(async (response) => {
  if (response.ok) {
    const data = await response.json();
    csrfToken = data.csrf || '';
    showDashboard();
  }
}).catch(() => undefined);
