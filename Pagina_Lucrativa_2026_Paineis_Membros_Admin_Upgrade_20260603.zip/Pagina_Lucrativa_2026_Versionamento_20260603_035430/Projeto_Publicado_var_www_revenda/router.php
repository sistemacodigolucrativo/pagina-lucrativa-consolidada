<?php
declare(strict_types=1);

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$base = str_starts_with($path, '/revenda') ? '/revenda' : '';
$relativePath = $base !== '' ? substr($path, strlen($base)) : $path;
$relativePath = $relativePath === '' ? '/' : $relativePath;
$file = __DIR__ . $relativePath;

if ($relativePath !== '/' && is_file($file)) {
    return false;
}

if (preg_match('#^/(?:p|r)/[^/]+/?$#', $relativePath)) {
    require __DIR__ . '/r/index.php';
    return true;
}

if ($relativePath === '/demo' || $relativePath === '/demo/') {
    require __DIR__ . '/demo/index.php';
    return true;
}

if ($relativePath === '/') {
    require __DIR__ . '/index.html';
    return true;
}

http_response_code(404);
echo 'Página não encontrada.';
return true;
