<?php
declare(strict_types=1);

$isHttpsRequest = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
$cookiePath = str_starts_with(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/', '/revenda') ? '/revenda' : '/';
session_set_cookie_params([
    'lifetime' => 0,
    'path' => $cookiePath,
    'secure' => $isHttpsRequest,
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

define('APP_ROOT', dirname(__DIR__));
$storageRoot = getenv('REVENDA_STORAGE_DIR') ?: (is_dir('/var/lib/revenda-pwa') ? '/var/lib/revenda-pwa' : APP_ROOT . '/private-storage');
define('STORAGE_ROOT', $storageRoot);
define('DATA_DIR', STORAGE_ROOT . '/data');
define('UPLOAD_DIR', STORAGE_ROOT . '/uploads');
define('DB_PATH', DATA_DIR . '/revenda_pwa.sqlite');
define('SYSTEM_TERMS_VERSION', '2026-06-01');

if (!is_dir(DATA_DIR)) {
    mkdir(DATA_DIR, 0775, true);
}

if (!is_dir(UPLOAD_DIR . '/receipts')) {
    mkdir(UPLOAD_DIR . '/receipts', 0775, true);
}

if (!is_dir(UPLOAD_DIR . '/branding')) {
    mkdir(UPLOAD_DIR . '/branding', 0775, true);
}

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function request_json(): array
{
    $raw = file_get_contents('php://input') ?: '';
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function clean_text(?string $value, int $max = 600): string
{
    $value = trim((string) $value);
    $value = strip_tags($value);
    $value = preg_replace('/\s+/u', ' ', $value) ?: '';
    return mb_substr($value, 0, $max);
}

function clean_multiline(?string $value, int $max = 4000): string
{
    $value = trim((string) $value);
    $value = strip_tags($value);
    $value = preg_replace("/[ \t]+/u", ' ', $value) ?: '';
    return mb_substr($value, 0, $max);
}

function normalize_email(?string $email): string
{
    return mb_strtolower(clean_text($email, 190));
}

function slugify(string $value): string
{
    $value = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) ?: $value;
    $value = strtolower($value);
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?: '';
    $value = trim($value, '-');
    return $value !== '' ? mb_substr($value, 0, 70) : 'pagina';
}

function generate_access_key(): string
{
    $token = strtoupper(bin2hex(random_bytes(8)));
    $groups = str_split($token, 4);
    return 'PL-' . date('Y') . '-' . implode('-', $groups);
}

function db(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    if (!extension_loaded('pdo_sqlite')) {
        json_response([
            'ok' => false,
            'error' => 'A extensão pdo_sqlite do PHP não está ativa neste servidor.',
        ], 500);
    }

    $pdo = new PDO('sqlite:' . DB_PATH, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $pdo->exec('PRAGMA foreign_keys = ON');
    init_database($pdo);
    return $pdo;
}

function init_database(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS revendedores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            whatsapp TEXT,
            chave_acesso TEXT UNIQUE,
            status TEXT NOT NULL DEFAULT 'pendente',
            template_escolhido TEXT NOT NULL DEFAULT 'classico',
            slug TEXT UNIQUE,
            regras_aceitas_em TEXT,
            termos_versao TEXT,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS configuracoes_revendedor (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL UNIQUE,
            nome_marca TEXT,
            pix TEXT,
            pix_tipo TEXT,
            pix_chave TEXT,
            pix_recebedor TEXT,
            pix_cidade TEXT,
            pix_instrucoes TEXT,
            comprovante_mensagem TEXT,
            dados_bancarios TEXT,
            checkout_url TEXT,
            preco TEXT,
            titulo_oferta TEXT,
            texto_oferta TEXT,
            texto_botao TEXT,
            depoimentos TEXT,
            cor_tema TEXT,
            logo TEXT,
            imagem_principal TEXT,
            public_name TEXT,
            profile_photo TEXT,
            profile_bio TEXT,
            FOREIGN KEY (user_id) REFERENCES revendedores(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS pedidos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL,
            nome TEXT NOT NULL,
            whatsapp TEXT,
            transaction_id TEXT,
            comprovante TEXT,
            status_pagamento TEXT NOT NULL DEFAULT 'pendente',
            valor_configurado TEXT,
            observacao_admin TEXT,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS banimentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            motivo TEXT,
            status TEXT NOT NULL DEFAULT 'ativo',
            data_bloqueio TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES revendedores(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS admin (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario TEXT NOT NULL UNIQUE,
            senha_hash TEXT NOT NULL,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS rate_limits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scope TEXT NOT NULL,
            identifier TEXT NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0,
            first_attempt_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL,
            UNIQUE(scope, identifier)
        );

        CREATE TABLE IF NOT EXISTS system_settings (
            setting_key TEXT PRIMARY KEY,
            setting_value TEXT,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
    ");

    ensure_column($pdo, 'revendedores', 'regras_aceitas_em', 'TEXT');
    ensure_column($pdo, 'revendedores', 'termos_versao', 'TEXT');
    ensure_column($pdo, 'configuracoes_revendedor', 'pix_tipo', 'TEXT');
    ensure_column($pdo, 'configuracoes_revendedor', 'pix_chave', 'TEXT');
    ensure_column($pdo, 'configuracoes_revendedor', 'pix_recebedor', 'TEXT');
    ensure_column($pdo, 'configuracoes_revendedor', 'pix_cidade', 'TEXT');
    ensure_column($pdo, 'configuracoes_revendedor', 'pix_instrucoes', 'TEXT');
    ensure_column($pdo, 'configuracoes_revendedor', 'comprovante_mensagem', 'TEXT');
    ensure_column($pdo, 'configuracoes_revendedor', 'public_name', 'TEXT');
    ensure_column($pdo, 'configuracoes_revendedor', 'profile_photo', 'TEXT');
    ensure_column($pdo, 'configuracoes_revendedor', 'profile_bio', 'TEXT');
    ensure_column($pdo, 'pedidos', 'valor_configurado', 'TEXT');

    $count = (int) $pdo->query('SELECT COUNT(*) FROM admin')->fetchColumn();
    if ($count === 0) {
        $password = getenv('REVENDA_ADMIN_PASSWORD') ?: 'admin123456';
        $stmt = $pdo->prepare('INSERT INTO admin (usuario, senha_hash) VALUES (?, ?)');
        $stmt->execute(['admin', password_hash($password, PASSWORD_DEFAULT)]);
    }

    seed_system_settings($pdo);
}

function seed_system_settings(PDO $pdo): void
{
    $defaults = [
        'checkout_title' => 'Ative AGORA por apenas R$ 10,00',
        'checkout_price' => 'R$ 10,00',
        'checkout_pix_type' => 'Chave PIX',
        'checkout_pix_key' => getenv('REVENDA_PIX_KEY') ?: '',
        'checkout_pix_receiver' => getenv('REVENDA_PIX_RECEIVER') ?: 'Página Lucrativa 2026',
        'checkout_pix_instructions' => 'Copie a chave PIX, pague R$ 10,00 e envie o comprovante com seus dados para liberar o acesso.',
        'checkout_note' => 'Acesso por valor único, sem mensalidade, enquanto as regras de uso forem respeitadas.',
    ];

    $stmt = $pdo->prepare('INSERT OR IGNORE INTO system_settings (setting_key, setting_value) VALUES (?, ?)');
    foreach ($defaults as $key => $value) {
        $stmt->execute([$key, $value]);
    }

    foreach (global_text_defaults() as $key => $value) {
        $stmt->execute(['global_text_' . $key, $value]);
    }
}

function system_settings(PDO $pdo): array
{
    $settings = [];
    $rows = $pdo->query('SELECT setting_key, setting_value FROM system_settings')->fetchAll();
    foreach ($rows as $row) {
        $settings[(string) $row['setting_key']] = (string) ($row['setting_value'] ?? '');
    }
    return $settings;
}

function save_system_settings(PDO $pdo, array $settings): void
{
    $stmt = $pdo->prepare('
        INSERT INTO system_settings (setting_key, setting_value, updated_at)
        VALUES (?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(setting_key) DO UPDATE SET
            setting_value = excluded.setting_value,
            updated_at = CURRENT_TIMESTAMP
    ');

    foreach ($settings as $key => $value) {
        $stmt->execute([$key, $value]);
    }
}

function checkout_settings(PDO $pdo): array
{
    $settings = system_settings($pdo);
    return [
        'title' => $settings['checkout_title'] ?? 'Acesso Página Lucrativa 2026',
        'price' => $settings['checkout_price'] ?? 'R$ 10,00',
        'pix_type' => $settings['checkout_pix_type'] ?? 'Chave PIX',
        'pix_key' => $settings['checkout_pix_key'] ?? '',
        'pix_receiver' => $settings['checkout_pix_receiver'] ?? 'Página Lucrativa 2026',
        'pix_instructions' => $settings['checkout_pix_instructions'] ?? '',
        'note' => $settings['checkout_note'] ?? '',
    ];
}

function global_text_definitions(): array
{
    return [
        [
            'id' => 'hero',
            'title' => '1. Topo principal',
            'fields' => [
                ['key' => 'hero_eyebrow', 'label' => 'Texto pequeno acima do título', 'type' => 'text', 'value' => 'página pronta · pix próprio · link para divulgar'],
                ['key' => 'hero_title', 'label' => 'Título principal', 'type' => 'textarea', 'value' => 'Sua página de vendas pronta: Página Lucrativa 2026, feita para apresentar sua oportunidade com clareza e profissionalismo.'],
                ['key' => 'hero_lead', 'label' => 'Subtítulo principal', 'type' => 'textarea', 'value' => 'Chega de perder tempo explicando tudo por mensagem! Você não cria nada do zero: você ativa, configura seus dados em 2 minutos e ganha um link exclusivo para divulgar onde quiser — celular, computador ou tablet.'],
                ['key' => 'hero_cta', 'label' => 'Botão principal', 'type' => 'text', 'value' => 'Ativar minha Página Lucrativa'],
                ['key' => 'trust_1', 'label' => 'Selo 1', 'type' => 'text', 'value' => 'Seu nome'],
                ['key' => 'trust_2', 'label' => 'Selo 2', 'type' => 'text', 'value' => 'Seu PIX'],
                ['key' => 'trust_3', 'label' => 'Selo 3', 'type' => 'text', 'value' => 'Seu WhatsApp'],
                ['key' => 'trust_4', 'label' => 'Selo 4', 'type' => 'text', 'value' => 'Seu link'],
            ],
        ],
        [
            'id' => 'recebe',
            'title' => '2. O que voce recebe',
            'fields' => [
                ['key' => 'receive_label', 'label' => 'Titulo pequeno do card', 'type' => 'text', 'value' => 'O que você recebe'],
                ['key' => 'receive_title', 'label' => 'Titulo do card', 'type' => 'textarea', 'value' => 'Página completa e atualizada 2026, com estrutura pronta para vender melhor.'],
                ['key' => 'receive_item_1', 'label' => 'Item 1', 'type' => 'textarea', 'value' => 'Página completa e atualizada 2026: layout moderno, conteúdo pronto e otimizado para vender mais.'],
                ['key' => 'receive_item_2', 'label' => 'Item 2', 'type' => 'textarea', 'value' => 'Na ativação, o pagamento é feito para liberar seu acesso. Depois de configurar sua página, os interessados verão o PIX informado por você.'],
                ['key' => 'receive_item_3', 'label' => 'Item 3', 'type' => 'textarea', 'value' => 'Área de Membros fácil: edite tudo sem saber nada de tecnologia — nome, valor, contato e texto.'],
                ['key' => 'receive_item_4', 'label' => 'Item 4', 'type' => 'textarea', 'value' => 'Modelos profissionais: escolha entre visuais prontos que passam confiança e aumentam suas vendas.'],
                ['key' => 'receive_item_5', 'label' => 'Item 5', 'type' => 'textarea', 'value' => 'Link exclusivo: use na bio, status, grupos ou conversas pessoais.'],
                ['key' => 'receive_item_6', 'label' => 'Item 6', 'type' => 'textarea', 'value' => 'Conteúdos e cursos inclusos: tudo o que você precisa aprender para divulgar certo e buscar resultados.'],
                ['key' => 'micro_warning', 'label' => 'Aviso abaixo do card', 'type' => 'textarea', 'value' => 'Resultado depende da sua ação, mas a melhor estrutura e o melhor caminho já estão prontos para você.'],
            ],
        ],
        [
            'id' => 'problema',
            'title' => '3. O problema real',
            'fields' => [
                ['key' => 'problem_eyebrow', 'label' => 'Texto pequeno', 'type' => 'text', 'value' => 'O problema real'],
                ['key' => 'problem_title', 'label' => 'Titulo', 'type' => 'textarea', 'value' => 'O problema? Você gasta tempo explicando tudo várias vezes, o cliente fica confuso e acaba desistindo antes de comprar.'],
                ['key' => 'problem_text_1', 'label' => 'Texto 1', 'type' => 'textarea', 'value' => 'A solução 2026: com apenas um link, você mostra tudo organizado: o que vende, quanto custa, como pagar e como falar com você.'],
                ['key' => 'problem_text_2', 'label' => 'Texto 2', 'type' => 'textarea', 'value' => 'Mais clareza, mais confiança e muito menos trabalho repetido.'],
                ['key' => 'problem_card_1_title', 'label' => 'Card 1 titulo', 'type' => 'text', 'value' => 'Antes'],
                ['key' => 'problem_card_1_text', 'label' => 'Card 1 texto', 'type' => 'text', 'value' => 'explicação enrolada, pagamento confuso, pouca venda.'],
                ['key' => 'problem_card_2_title', 'label' => 'Card 2 titulo', 'type' => 'text', 'value' => 'Agora'],
                ['key' => 'problem_card_2_text', 'label' => 'Card 2 texto', 'type' => 'text', 'value' => 'página profissional, dados visíveis e decisão rápida.'],
                ['key' => 'problem_card_3_title', 'label' => 'Card 3 titulo', 'type' => 'text', 'value' => 'Na prática'],
                ['key' => 'problem_card_3_text', 'label' => 'Card 3 texto', 'type' => 'text', 'value' => 'mais clareza para o cliente e mais lucro para você.'],
            ],
        ],
        [
            'id' => 'depoimentos',
            'title' => '4. Depoimentos',
            'fields' => [
                ['key' => 'testimonials_eyebrow', 'label' => 'Texto pequeno', 'type' => 'text', 'value' => 'Depoimentos'],
                ['key' => 'testimonials_title', 'label' => 'Titulo', 'type' => 'textarea', 'value' => 'Comentários de quem usa uma página própria para apresentar a oportunidade com mais clareza.'],
                ['key' => 'testimonials_text', 'label' => 'Subtitulo', 'type' => 'textarea', 'value' => 'Os relatos abaixo destacam organização, clareza no PIX, link próprio e mais facilidade para explicar a Página Lucrativa 2026.'],
            ],
        ],
        [
            'id' => 'como_funciona',
            'title' => '5. Como funciona',
            'fields' => [
                ['key' => 'how_eyebrow', 'label' => 'Texto pequeno', 'type' => 'text', 'value' => 'Como funciona'],
                ['key' => 'how_title', 'label' => 'Titulo', 'type' => 'text', 'value' => 'Processo rápido, 100% online e sem complicação.'],
                ['key' => 'how_text', 'label' => 'Subtitulo', 'type' => 'textarea', 'value' => 'Ative, configure seus dados e divulgue seu link em poucos passos.'],
                ['key' => 'how_step_1_title', 'label' => 'Passo 1 titulo', 'type' => 'text', 'value' => 'Pague R$ 10,00 por PIX'],
                ['key' => 'how_step_1_text', 'label' => 'Passo 1 texto', 'type' => 'text', 'value' => 'Valor único, sem mensalidades.'],
                ['key' => 'how_step_2_title', 'label' => 'Passo 2 titulo', 'type' => 'text', 'value' => 'Envie o comprovante'],
                ['key' => 'how_step_2_text', 'label' => 'Passo 2 texto', 'type' => 'text', 'value' => 'Liberação feita rapidamente após a conferência.'],
                ['key' => 'how_step_3_title', 'label' => 'Passo 3 titulo', 'type' => 'text', 'value' => 'Receba sua chave de acesso'],
                ['key' => 'how_step_3_text', 'label' => 'Passo 3 texto', 'type' => 'text', 'value' => 'Direto no e-mail ou WhatsApp informado.'],
                ['key' => 'how_step_4_title', 'label' => 'Passo 4 titulo', 'type' => 'text', 'value' => 'Configure em 2 minutos'],
                ['key' => 'how_step_4_text', 'label' => 'Passo 4 texto', 'type' => 'text', 'value' => 'Coloque seus dados, escolha um modelo novo 2026 e pronto.'],
                ['key' => 'how_step_5_title', 'label' => 'Passo 5 titulo', 'type' => 'text', 'value' => 'Divulgue seu link'],
                ['key' => 'how_step_5_text', 'label' => 'Passo 5 texto', 'type' => 'text', 'value' => 'Sua página fica disponível 24h por dia para apresentar a oportunidade com clareza.'],
            ],
        ],
        [
            'id' => 'personalizar',
            'title' => '6. Personalizar',
            'fields' => [
                ['key' => 'customize_eyebrow', 'label' => 'Texto pequeno', 'type' => 'text', 'value' => 'O que você recebe'],
                ['key' => 'customize_title', 'label' => 'Titulo', 'type' => 'textarea', 'value' => 'Depois da ativação, você recebe uma página própria para apresentar a Página Lucrativa 2026 com seus dados de contato e pagamento.'],
                ['key' => 'customize_text', 'label' => 'Subtitulo', 'type' => 'textarea', 'value' => 'A Página Lucrativa 2026 é uma estrutura pronta para você ativar, personalizar com seus dados e divulgar seu próprio link de apresentação.'],
                ['key' => 'customize_cta', 'label' => 'Botao', 'type' => 'text', 'value' => 'Quero ativar agora'],
                ['key' => 'feature_1_title', 'label' => 'Recurso 1 titulo', 'type' => 'text', 'value' => 'Página 2026'],
                ['key' => 'feature_1_text', 'label' => 'Recurso 1 texto', 'type' => 'text', 'value' => 'layout moderno, conteúdo pronto e estrutura otimizada.'],
                ['key' => 'feature_2_title', 'label' => 'Recurso 2 titulo', 'type' => 'text', 'value' => 'Pagamento direto'],
                ['key' => 'feature_2_text', 'label' => 'Recurso 2 texto', 'type' => 'textarea', 'value' => 'quando alguém seguir as instruções da sua página e pagar o acesso pelo PIX informado por você, o valor vai direto para a sua chave configurada na sua página.'],
                ['key' => 'feature_3_title', 'label' => 'Recurso 3 titulo', 'type' => 'text', 'value' => 'Área de Membros'],
                ['key' => 'feature_3_text', 'label' => 'Recurso 3 texto', 'type' => 'text', 'value' => 'edite nome, valor, contato, texto e modelo visual.'],
                ['key' => 'feature_4_title', 'label' => 'Recurso 4 titulo', 'type' => 'text', 'value' => 'Modelos profissionais'],
                ['key' => 'feature_4_text', 'label' => 'Recurso 4 texto', 'type' => 'text', 'value' => 'visuais prontos para passar mais confiança.'],
                ['key' => 'feature_5_title', 'label' => 'Recurso 5 titulo', 'type' => 'text', 'value' => 'Link exclusivo'],
                ['key' => 'feature_5_text', 'label' => 'Recurso 5 texto', 'type' => 'text', 'value' => 'divulgue na bio, status, grupos e conversas.'],
                ['key' => 'feature_6_title', 'label' => 'Recurso 6 titulo', 'type' => 'text', 'value' => 'Conteúdos inclusos'],
                ['key' => 'feature_6_text', 'label' => 'Recurso 6 texto', 'type' => 'text', 'value' => 'orientações para divulgar certo e buscar melhores resultados.'],
            ],
        ],
        [
            'id' => 'oportunidade',
            'title' => '7. A oportunidade',
            'fields' => [
                ['key' => 'opportunity_eyebrow', 'label' => 'Texto pequeno', 'type' => 'text', 'value' => 'A oportunidade'],
                ['key' => 'opportunity_title', 'label' => 'Titulo', 'type' => 'textarea', 'value' => 'Enquanto muita gente improvisa, você pode se apresentar com uma estrutura pronta.'],
                ['key' => 'opportunity_text', 'label' => 'Subtitulo', 'type' => 'textarea', 'value' => 'Uma estrutura pronta para quem quer começar a divulgar uma oportunidade online com página própria, PIX, WhatsApp e link personalizado.'],
                ['key' => 'opportunity_1_title', 'label' => 'Card 1 titulo', 'type' => 'text', 'value' => 'Velocidade'],
                ['key' => 'opportunity_1_text', 'label' => 'Card 1 texto', 'type' => 'text', 'value' => 'Você configura sem começar do zero.'],
                ['key' => 'opportunity_2_title', 'label' => 'Card 2 titulo', 'type' => 'text', 'value' => 'Controle'],
                ['key' => 'opportunity_2_text', 'label' => 'Card 2 texto', 'type' => 'text', 'value' => 'Você altera preço, PIX, WhatsApp e texto quando precisar.'],
                ['key' => 'opportunity_3_title', 'label' => 'Card 3 titulo', 'type' => 'text', 'value' => 'Clareza'],
                ['key' => 'opportunity_3_text', 'label' => 'Card 3 texto', 'type' => 'text', 'value' => 'A pessoa entende o que é, quanto custa e como falar com você.'],
                ['key' => 'opportunity_4_title', 'label' => 'Card 4 titulo', 'type' => 'text', 'value' => 'Propriedade'],
                ['key' => 'opportunity_4_text', 'label' => 'Card 4 texto', 'type' => 'text', 'value' => 'Seu nome, sua página, seu PIX e seu link.'],
            ],
        ],
        [
            'id' => 'modelos',
            'title' => '8. Modelos',
            'fields' => [
                ['key' => 'models_eyebrow', 'label' => 'Texto pequeno', 'type' => 'text', 'value' => 'Estilos de página'],
                ['key' => 'models_title', 'label' => 'Titulo', 'type' => 'text', 'value' => 'Modelos atualizados 2026 — feitos para converter.'],
                ['key' => 'models_text', 'label' => 'Subtitulo', 'type' => 'textarea', 'value' => 'Todos prontos, editáveis e otimizados para celular. Escolha o que mais combina com o que você vende.'],
                ['key' => 'models_hint', 'label' => 'Instrucao mobile', 'type' => 'text', 'value' => 'Passe o dedo para o lado e veja os estilos disponíveis →'],
            ],
        ],
        [
            'id' => 'checkout',
            'title' => '9. Checkout e ativacao',
            'fields' => [
                ['key' => 'checkout_eyebrow', 'label' => 'Texto pequeno do checkout', 'type' => 'text', 'value' => 'Ativação por PIX'],
                ['key' => 'checkout_help_title', 'label' => 'Titulo do aviso', 'type' => 'text', 'value' => 'Como ativar'],
                ['key' => 'checkout_help_text', 'label' => 'Texto do aviso', 'type' => 'textarea', 'value' => 'Faça o PIX, envie o comprovante e aguarde a conferência para receber sua chave de acesso.'],
                ['key' => 'checkout_card_eyebrow', 'label' => 'Texto pequeno do formulario', 'type' => 'text', 'value' => 'Pagamento manual'],
                ['key' => 'checkout_card_title', 'label' => 'Titulo do formulario', 'type' => 'text', 'value' => 'Ative sua página agora'],
                ['key' => 'checkout_badge', 'label' => 'Etiqueta do formulario', 'type' => 'text', 'value' => 'PIX + comprovante'],
                ['key' => 'checkout_submit', 'label' => 'Botao do comprovante', 'type' => 'text', 'value' => 'Enviar comprovante e solicitar chave'],
            ],
        ],
        [
            'id' => 'desbloquear',
            'title' => '10. Area de Membros',
            'fields' => [
                ['key' => 'unlock_eyebrow', 'label' => 'Texto pequeno', 'type' => 'text', 'value' => 'Área de Membros'],
                ['key' => 'unlock_title', 'label' => 'Titulo', 'type' => 'text', 'value' => 'Já recebeu sua chave?'],
                ['key' => 'unlock_text', 'label' => 'Subtitulo', 'type' => 'textarea', 'value' => 'Entre com o e-mail usado no pedido e a chave de ativação. Depois disso, configure sua página, aceite as regras e gere seu link.'],
                ['key' => 'unlock_button', 'label' => 'Botao', 'type' => 'text', 'value' => 'Entrar e configurar minha página'],
            ],
        ],
        [
            'id' => 'regras',
            'title' => '11. Regras de uso',
            'fields' => [
                ['key' => 'rules_eyebrow', 'label' => 'Texto pequeno', 'type' => 'text', 'value' => 'Regras de uso'],
                ['key' => 'rules_title', 'label' => 'Titulo', 'type' => 'text', 'value' => 'Regras simples para manter sua página sempre ativa.'],
                ['key' => 'rules_text', 'label' => 'Subtitulo', 'type' => 'textarea', 'value' => 'Use sua página com clareza, ética e dados verdadeiros. Assim sua estrutura continua ativa e confiável.'],
                ['key' => 'rules_item_1', 'label' => 'Regra 1', 'type' => 'text', 'value' => 'use dados verdadeiros e completos'],
                ['key' => 'rules_item_2', 'label' => 'Regra 2', 'type' => 'text', 'value' => 'divulgue com clareza e ética'],
                ['key' => 'rules_item_3', 'label' => 'Regra 3', 'type' => 'text', 'value' => 'não faça promessas falsas'],
                ['key' => 'rules_item_4', 'label' => 'Regra 4', 'type' => 'text', 'value' => 'sem spam ou mensagens abusivas'],
                ['key' => 'rules_card_title', 'label' => 'Titulo do aviso', 'type' => 'text', 'value' => 'Importante'],
                ['key' => 'rules_card_text', 'label' => 'Texto do aviso', 'type' => 'textarea', 'value' => 'Essa é a estrutura pronta para você; o sucesso vem da sua dedicação e da forma como se comunica.'],
            ],
        ],
        [
            'id' => 'final',
            'title' => '12. Chamada final',
            'fields' => [
                ['key' => 'final_eyebrow', 'label' => 'Texto pequeno', 'type' => 'text', 'value' => 'Próximo passo'],
                ['key' => 'final_title', 'label' => 'Titulo', 'type' => 'textarea', 'value' => 'Continue perdendo tempo explicando tudo várias vezes, ou ative AGORA a Página Lucrativa 2026.'],
                ['key' => 'final_text', 'label' => 'Subtitulo', 'type' => 'textarea', 'value' => 'A Página Lucrativa 2026 é uma estrutura pronta para você ativar, personalizar com seus dados e divulgar seu próprio link. Ela organiza a apresentação da oportunidade, mostra seu contato, seu PIX e facilita o envio para interessados pelo WhatsApp, Instagram, bio, grupos e conversas.'],
                ['key' => 'final_primary_cta', 'label' => 'Botao principal', 'type' => 'text', 'value' => 'QUERO MINHA PÁGINA LUCRATIVA 2026'],
                ['key' => 'final_secondary_cta', 'label' => 'Botao secundario', 'type' => 'text', 'value' => 'Já tenho uma chave'],
                ['key' => 'sticky_cta', 'label' => 'Botao flutuante mobile', 'type' => 'text', 'value' => 'Ativar Página Lucrativa'],
            ],
        ],
        [
            'id' => 'rodape',
            'title' => '13. Rodape',
            'fields' => [
                ['key' => 'footer_copyright', 'label' => 'Copyright', 'type' => 'text', 'value' => '© 2026 Página Lucrativa 2026 - Todos os direitos reservados.'],
                ['key' => 'footer_subtitle', 'label' => 'Texto final', 'type' => 'text', 'value' => 'Área de Membros, PIX, página personalizada e link próprio.'],
            ],
        ],
    ];
}

function global_text_defaults(): array
{
    $defaults = [];
    foreach (global_text_definitions() as $section) {
        foreach ($section['fields'] as $field) {
            $defaults[$field['key']] = $field['value'];
        }
    }
    return $defaults;
}

function global_texts(PDO $pdo): array
{
    $settings = system_settings($pdo);
    $texts = global_text_defaults();
    foreach ($texts as $key => $default) {
        $storedKey = 'global_text_' . $key;
        if (array_key_exists($storedKey, $settings)) {
            $texts[$key] = (string) $settings[$storedKey];
        }
    }
    return $texts;
}

function global_text_sections(PDO $pdo): array
{
    $texts = global_texts($pdo);
    $sections = global_text_definitions();
    foreach ($sections as &$section) {
        foreach ($section['fields'] as &$field) {
            $field['value'] = $texts[$field['key']] ?? $field['value'];
        }
    }
    unset($section, $field);
    return $sections;
}

function save_global_texts(PDO $pdo, array $values): void
{
    $valid = [];
    foreach (global_text_definitions() as $section) {
        foreach ($section['fields'] as $field) {
            $valid[$field['key']] = $field['type'];
        }
    }

    $settings = [];
    foreach ($values as $key => $value) {
        if (!isset($valid[$key])) {
            continue;
        }
        $settings['global_text_' . $key] = $valid[$key] === 'textarea'
            ? clean_multiline((string) $value, 2000)
            : clean_text((string) $value, 500);
    }

    if ($settings !== []) {
        save_system_settings($pdo, $settings);
    }
}

function ensure_column(PDO $pdo, string $table, string $column, string $definition): void
{
    $stmt = $pdo->query("PRAGMA table_info($table)");
    $columns = $stmt ? $stmt->fetchAll() : [];
    foreach ($columns as $item) {
        if (($item['name'] ?? '') === $column) {
            return;
        }
    }

    $pdo->exec("ALTER TABLE $table ADD COLUMN $column $definition");
}

function require_admin(): void
{
    if (empty($_SESSION['admin_id'])) {
        json_response(['ok' => false, 'error' => 'Login administrativo necessário.'], 401);
    }
}

function require_csrf(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }

    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!$token || empty($_SESSION['admin_csrf']) || !hash_equals((string) $_SESSION['admin_csrf'], (string) $token)) {
        json_response(['ok' => false, 'error' => 'Token de segurança inválido.'], 403);
    }
}

function require_reseller(): int
{
    $id = (int) ($_SESSION['reseller_id'] ?? 0);
    if ($id <= 0) {
        json_response(['ok' => false, 'error' => 'Acesso do dono da página necessário.'], 401);
    }
    return $id;
}

function client_identifier(): string
{
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    return hash('sha256', (string) $ip);
}

function rate_limit_guard(PDO $pdo, string $scope, int $limit, int $windowSeconds): void
{
    $identifier = client_identifier();
    $now = time();
    $minTime = $now - $windowSeconds;

    $stmt = $pdo->prepare('DELETE FROM rate_limits WHERE scope = ? AND first_attempt_at < ?');
    $stmt->execute([$scope, $minTime]);

    $stmt = $pdo->prepare('SELECT attempts FROM rate_limits WHERE scope = ? AND identifier = ?');
    $stmt->execute([$scope, $identifier]);
    $attempts = (int) ($stmt->fetchColumn() ?: 0);

    if ($attempts >= $limit) {
        json_response(['ok' => false, 'error' => 'Muitas tentativas. Aguarde alguns minutos e tente novamente.'], 429);
    }
}

function rate_limit_hit(PDO $pdo, string $scope): void
{
    $identifier = client_identifier();
    $now = time();
    $stmt = $pdo->prepare('
        INSERT INTO rate_limits (scope, identifier, attempts, first_attempt_at, updated_at)
        VALUES (?, ?, 1, ?, ?)
        ON CONFLICT(scope, identifier) DO UPDATE SET
            attempts = attempts + 1,
            updated_at = excluded.updated_at
    ');
    $stmt->execute([$scope, $identifier, $now, $now]);
}

function rate_limit_clear(PDO $pdo, string $scope): void
{
    $stmt = $pdo->prepare('DELETE FROM rate_limits WHERE scope = ? AND identifier = ?');
    $stmt->execute([$scope, client_identifier()]);
}

function templates_catalog(): array
{
    return [
        ['id' => 'classico', 'name' => 'Clássico'],
        ['id' => 'dark', 'name' => 'Escuro premium'],
        ['id' => 'minimal', 'name' => 'Minimalista'],
        ['id' => 'whatsapp', 'name' => 'WhatsApp direto'],
        ['id' => 'pix', 'name' => 'Pix direto'],
        ['id' => 'prova', 'name' => 'Prova social'],
        ['id' => 'agressivo', 'name' => 'Venda direta'],
        ['id' => 'institucional', 'name' => 'Institucional'],
        ['id' => 'mobile', 'name' => 'Tela rápida'],
        ['id' => 'original', 'name' => 'Página Lucrativa original modernizada'],
    ];
}

function valid_template(string $id): bool
{
    foreach (templates_catalog() as $template) {
        if ($template['id'] === $id) {
            return true;
        }
    }
    return false;
}

function app_base_path(): string
{
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $uri = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';

    if (str_starts_with($script, '/revenda/') || $script === '/revenda' || str_starts_with($uri, '/revenda/')) {
        return '/revenda';
    }

    return '';
}

function public_origin(): string
{
    $fixed = trim((string) (getenv('REVENDA_PUBLIC_URL') ?: ''));
    if ($fixed !== '') {
        return rtrim($fixed, '/');
    }

    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return rtrim($scheme . '://' . $host . app_base_path(), '/');
}

function receipt_absolute_path(?string $storedPath): ?string
{
    $storedPath = clean_text($storedPath ?? '', 240);
    if ($storedPath === '') {
        return null;
    }

    $fileName = basename($storedPath);
    $path = UPLOAD_DIR . '/receipts/' . $fileName;
    return is_file($path) ? $path : null;
}
