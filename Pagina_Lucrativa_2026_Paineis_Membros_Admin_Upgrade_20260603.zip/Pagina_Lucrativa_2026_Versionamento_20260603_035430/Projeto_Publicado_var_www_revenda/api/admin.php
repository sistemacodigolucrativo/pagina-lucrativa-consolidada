<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$action = $_GET['action'] ?? '';
$pdo = db();

if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    rate_limit_guard($pdo, 'admin_login', 6, 900);
    $data = request_json();
    $usuario = clean_text($data['usuario'] ?? '', 80);
    $senha = (string) ($data['senha'] ?? '');

    $stmt = $pdo->prepare('SELECT * FROM admin WHERE usuario = ? LIMIT 1');
    $stmt->execute([$usuario]);
    $admin = $stmt->fetch();

    if (!$admin || !password_verify($senha, $admin['senha_hash'])) {
        rate_limit_hit($pdo, 'admin_login');
        json_response(['ok' => false, 'error' => 'Login inválido.'], 403);
    }

    rate_limit_clear($pdo, 'admin_login');
    session_regenerate_id(true);
    $_SESSION['admin_id'] = (int) $admin['id'];
    $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
    json_response(['ok' => true, 'admin' => ['id' => $admin['id'], 'usuario' => $admin['usuario']], 'csrf' => $_SESSION['admin_csrf']]);
}

if ($action === 'logout') {
    unset($_SESSION['admin_id']);
    unset($_SESSION['admin_csrf']);
    json_response(['ok' => true]);
}

if ($action === 'me') {
    require_admin();
    if (empty($_SESSION['admin_csrf'])) {
        $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
    }
    json_response(['ok' => true, 'admin' => ['id' => $_SESSION['admin_id']], 'csrf' => $_SESSION['admin_csrf']]);
}

require_admin();
require_csrf();

if ($action === 'orders') {
    $orders = $pdo->query('SELECT * FROM pedidos ORDER BY id DESC')->fetchAll();
    json_response(['ok' => true, 'orders' => $orders]);
}

if ($action === 'checkout_settings') {
    json_response(['ok' => true, 'checkout' => checkout_settings($pdo)]);
}

if ($action === 'global_texts') {
    json_response(['ok' => true, 'sections' => global_text_sections($pdo)]);
}

if ($action === 'save_checkout_settings' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = request_json();
    save_system_settings($pdo, [
        'checkout_title' => clean_text($data['title'] ?? '', 160),
        'checkout_price' => clean_text($data['price'] ?? '', 40),
        'checkout_pix_type' => clean_text($data['pix_type'] ?? '', 60),
        'checkout_pix_key' => clean_text($data['pix_key'] ?? '', 240),
        'checkout_pix_receiver' => clean_text($data['pix_receiver'] ?? '', 160),
        'checkout_pix_instructions' => clean_multiline($data['pix_instructions'] ?? '', 1000),
        'checkout_note' => clean_multiline($data['note'] ?? '', 1000),
    ]);
    json_response(['ok' => true, 'checkout' => checkout_settings($pdo)]);
}

if ($action === 'save_global_texts' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = request_json();
    $values = is_array($data['values'] ?? null) ? $data['values'] : [];
    save_global_texts($pdo, $values);
    json_response(['ok' => true, 'sections' => global_text_sections($pdo)]);
}

if ($action === 'receipt') {
    $orderId = (int) ($_GET['id'] ?? 0);
    $stmt = $pdo->prepare('SELECT comprovante FROM pedidos WHERE id = ? LIMIT 1');
    $stmt->execute([$orderId]);
    $storedPath = (string) ($stmt->fetchColumn() ?: '');
    $path = receipt_absolute_path($storedPath);
    if (!$path) {
        http_response_code(404);
        echo 'Comprovante não encontrado.';
        exit;
    }

    $mime = mime_content_type($path) ?: 'application/octet-stream';
    header('Content-Type: ' . $mime);
    header('Content-Disposition: inline; filename="' . basename($path) . '"');
    header('X-Content-Type-Options: nosniff');
    readfile($path);
    exit;
}

if ($action === 'resellers') {
    $rows = $pdo->query('
        SELECT r.*, c.nome_marca, c.pix_tipo, c.pix_chave, c.pix_recebedor, c.pix_cidade, c.preco, c.titulo_oferta, c.cor_tema
        FROM revendedores r
        LEFT JOIN configuracoes_revendedor c ON c.user_id = r.id
        ORDER BY r.id DESC
    ')->fetchAll();
    json_response(['ok' => true, 'resellers' => $rows, 'origin' => public_origin()]);
}

if ($action === 'approve_order' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = request_json();
    $orderId = (int) ($data['id'] ?? 0);
    $stmt = $pdo->prepare('SELECT * FROM pedidos WHERE id = ? LIMIT 1');
    $stmt->execute([$orderId]);
    $order = $stmt->fetch();

    if (!$order) {
        json_response(['ok' => false, 'error' => 'Pedido não encontrado.'], 404);
    }

    $email = normalize_email($order['email']);
    $slugBase = slugify($order['nome']);
    $slug = $slugBase;
    $suffix = 2;
    while (true) {
        $stmt = $pdo->prepare('SELECT id FROM revendedores WHERE slug = ? LIMIT 1');
        $stmt->execute([$slug]);
        if (!$stmt->fetch()) {
            break;
        }
        $slug = $slugBase . '-' . $suffix;
        $suffix++;
    }

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('SELECT id FROM revendedores WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $existing = $stmt->fetch();

        if ($existing) {
            $resellerId = (int) $existing['id'];
            $stmt = $pdo->prepare('UPDATE revendedores SET nome = ?, whatsapp = ?, status = CASE WHEN chave_acesso IS NULL THEN ? ELSE status END, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?');
            $stmt->execute([$order['nome'], $order['whatsapp'], 'pendente', $resellerId]);
        } else {
            $stmt = $pdo->prepare('INSERT INTO revendedores (nome, email, whatsapp, status, slug) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$order['nome'], $email, $order['whatsapp'], 'pendente', $slug]);
            $resellerId = (int) $pdo->lastInsertId();
        }

        $stmt = $pdo->prepare('UPDATE pedidos SET status_pagamento = ?, observacao_admin = ? WHERE id = ?');
        $stmt->execute(['aprovado', clean_multiline($data['observacao_admin'] ?? '', 1000), $orderId]);
        $pdo->commit();
    } catch (Throwable $error) {
        $pdo->rollBack();
        json_response(['ok' => false, 'error' => 'Erro ao aprovar pedido.'], 500);
    }

    $stmt = $pdo->prepare('SELECT * FROM revendedores WHERE id = ?');
    $stmt->execute([$resellerId]);
    json_response(['ok' => true, 'reseller' => $stmt->fetch()]);
}

if ($action === 'generate_key' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = request_json();
    $id = (int) ($data['id'] ?? 0);
    $email = normalize_email($data['email'] ?? '');
    $name = clean_text($data['nome'] ?? '', 160);
    $whatsapp = clean_text($data['whatsapp'] ?? '', 40);
    $key = generate_access_key();

    if ($id > 0) {
        $stmt = $pdo->prepare('UPDATE revendedores SET chave_acesso = ?, status = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?');
        $stmt->execute([$key, 'ativo', $id]);
    } else {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $name === '') {
            json_response(['ok' => false, 'error' => 'Informe nome e e-mail para gerar a chave.'], 422);
        }
        $slugBase = slugify($name);
        $slug = $slugBase;
        $suffix = 2;
        while (true) {
            $stmt = $pdo->prepare('SELECT id FROM revendedores WHERE slug = ? LIMIT 1');
            $stmt->execute([$slug]);
            if (!$stmt->fetch()) break;
            $slug = $slugBase . '-' . $suffix++;
        }

        $stmt = $pdo->prepare('
            INSERT INTO revendedores (nome, email, whatsapp, chave_acesso, status, slug)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(email) DO UPDATE SET
                nome = excluded.nome,
                whatsapp = excluded.whatsapp,
                chave_acesso = excluded.chave_acesso,
                status = excluded.status,
                atualizado_em = CURRENT_TIMESTAMP
        ');
        $stmt->execute([$name, $email, $whatsapp, $key, 'ativo', $slug]);
    }

    json_response(['ok' => true, 'chave' => $key]);
}

if ($action === 'reject_order' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = request_json();
    $stmt = $pdo->prepare('UPDATE pedidos SET status_pagamento = ?, observacao_admin = ? WHERE id = ?');
    $stmt->execute(['recusado', clean_multiline($data['observacao_admin'] ?? '', 1000), (int) ($data['id'] ?? 0)]);
    json_response(['ok' => true]);
}

if ($action === 'update_reseller_status' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = request_json();
    $id = (int) ($data['id'] ?? 0);
    $status = clean_text($data['status'] ?? '', 30);
    $allowed = ['ativo', 'pendente', 'suspenso', 'banido'];
    if (!in_array($status, $allowed, true)) {
        json_response(['ok' => false, 'error' => 'Status inválido.'], 422);
    }

    $stmt = $pdo->prepare('UPDATE revendedores SET status = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?');
    $stmt->execute([$status, $id]);

    if (in_array($status, ['suspenso', 'banido'], true)) {
        $stmt = $pdo->prepare('INSERT INTO banimentos (user_id, motivo, status) VALUES (?, ?, ?)');
        $stmt->execute([$id, clean_multiline($data['motivo'] ?? '', 1000), $status]);
    }

    json_response(['ok' => true]);
}

if ($action === 'update_reseller' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = request_json();
    $id = (int) ($data['id'] ?? 0);
    $email = normalize_email($data['email'] ?? '');
    $name = clean_text($data['nome'] ?? '', 160);
    $whatsapp = clean_text($data['whatsapp'] ?? '', 40);
    $slug = slugify(clean_text($data['slug'] ?? '', 90));
    $status = clean_text($data['status'] ?? '', 30);
    $allowed = ['ativo', 'pendente', 'suspenso', 'banido'];

    if ($id <= 0 || !filter_var($email, FILTER_VALIDATE_EMAIL) || $name === '' || !in_array($status, $allowed, true)) {
        json_response(['ok' => false, 'error' => 'Dados inválidos para edição.'], 422);
    }

    $stmt = $pdo->prepare('UPDATE revendedores SET nome = ?, email = ?, whatsapp = ?, slug = ?, status = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?');
    $stmt->execute([$name, $email, $whatsapp, $slug, $status, $id]);
    json_response(['ok' => true]);
}

json_response(['ok' => false, 'error' => 'Ação administrativa inválida.'], 404);
