<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$action = $_GET['action'] ?? '';
$pdo = db();

if ($action === 'templates') {
    json_response(['ok' => true, 'templates' => templates_catalog()]);
}

if ($action === 'checkout_config') {
    json_response(['ok' => true, 'checkout' => checkout_settings($pdo)]);
}

if ($action === 'global_texts') {
    json_response(['ok' => true, 'texts' => global_texts($pdo)]);
}

if ($action === 'create_order' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    rate_limit_guard($pdo, 'create_order', 5, 900);

    $name = clean_text($_POST['nome'] ?? '', 160);
    $email = normalize_email($_POST['email'] ?? '');
    $whatsapp = clean_text($_POST['whatsapp'] ?? '', 40);
    $transactionId = clean_text($_POST['transaction_id'] ?? '', 120);
    $amount = clean_text($_POST['valor'] ?? '', 40);
    $note = clean_multiline($_POST['observacao'] ?? '', 1000);
    $receiptPath = null;

    if ($name === '') {
        json_response(['ok' => false, 'error' => 'Preencha o nome completo.'], 422);
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        json_response(['ok' => false, 'error' => 'E-mail inválido.'], 422);
    }

    if (!preg_match('/^[1-9]{2}9\d{8}$/', $whatsapp)) {
        json_response(['ok' => false, 'error' => 'WhatsApp inválido. Use apenas números com DDD e celular, exemplo: 11999999999.'], 422);
    }

    if (empty($_FILES['comprovante']['name'])) {
        rate_limit_hit($pdo, 'create_order');
        json_response(['ok' => false, 'error' => 'O comprovante é obrigatório.'], 422);
    }

    if ((int) $_FILES['comprovante']['size'] > 8 * 1024 * 1024) {
        rate_limit_hit($pdo, 'create_order');
        json_response(['ok' => false, 'error' => 'O comprovante deve ter no máximo 8MB.'], 422);
    }

    $tmp = $_FILES['comprovante']['tmp_name'];
    $mime = mime_content_type($tmp) ?: '';
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
    ];

    if (!isset($allowed[$mime])) {
        rate_limit_hit($pdo, 'create_order');
        json_response(['ok' => false, 'error' => 'Envie o comprovante em JPG, JPEG ou PNG.'], 422);
    }

    $fileName = date('Ymd-His') . '-' . bin2hex(random_bytes(6)) . '.' . $allowed[$mime];
    $target = UPLOAD_DIR . '/receipts/' . $fileName;
    if (!move_uploaded_file($tmp, $target)) {
        rate_limit_hit($pdo, 'create_order');
        json_response(['ok' => false, 'error' => 'Não foi possível salvar o comprovante.'], 500);
    }
    $receiptPath = 'receipts/' . $fileName;

    $stmt = $pdo->prepare('INSERT INTO pedidos (email, nome, whatsapp, transaction_id, comprovante, valor_configurado, observacao_admin) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$email, $name, $whatsapp, $transactionId, $receiptPath, $amount, $note]);
    rate_limit_hit($pdo, 'create_order');

    json_response(['ok' => true, 'message' => 'Comprovante enviado. Aguarde aprovação.']);
}

if ($action === 'unlock' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    rate_limit_guard($pdo, 'unlock', 8, 900);
    $data = request_json();
    $email = normalize_email($data['email'] ?? '');
    $key = strtoupper(clean_text($data['chave'] ?? '', 40));

    $stmt = $pdo->prepare('SELECT * FROM revendedores WHERE email = ? AND chave_acesso = ? LIMIT 1');
    $stmt->execute([$email, $key]);
    $reseller = $stmt->fetch();

    if (!$reseller) {
        rate_limit_hit($pdo, 'unlock');
        json_response(['ok' => false, 'error' => 'E-mail ou chave inválidos.'], 403);
    }

    if ($reseller['status'] !== 'ativo') {
        rate_limit_hit($pdo, 'unlock');
        json_response(['ok' => false, 'error' => 'Acesso não está ativo. Status atual: ' . $reseller['status']], 403);
    }

    rate_limit_clear($pdo, 'unlock');
    session_regenerate_id(true);
    $_SESSION['reseller_id'] = (int) $reseller['id'];
    json_response(['ok' => true, 'reseller' => $reseller]);
}

if ($action === 'reseller_me') {
    $id = require_reseller();
    $stmt = $pdo->prepare('
        SELECT r.*, r.whatsapp AS whatsapp_contato,
               c.nome_marca, c.pix, c.pix_tipo, c.pix_chave, c.pix_recebedor, c.pix_cidade, c.pix_instrucoes,
               c.comprovante_mensagem, c.dados_bancarios, c.checkout_url, c.preco, c.titulo_oferta,
               c.texto_oferta, c.texto_botao, c.depoimentos, c.cor_tema, c.logo, c.imagem_principal,
               c.public_name, c.profile_photo, c.profile_bio
        FROM revendedores r
        LEFT JOIN configuracoes_revendedor c ON c.user_id = r.id
        WHERE r.id = ?
    ');
    $stmt->execute([$id]);
    json_response(['ok' => true, 'reseller' => $stmt->fetch(), 'templates' => templates_catalog(), 'origin' => public_origin()]);
}

if ($action === 'save_reseller' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = require_reseller();
    $data = request_json();

    $name = clean_text($data['nome_marca'] ?? '', 120);
    $acceptedRules = !empty($data['aceite_regras']);
    if (!$acceptedRules) {
        json_response(['ok' => false, 'error' => 'Você precisa aceitar as regras do sistema antes de configurar a página.'], 422);
    }

    $slugBase = slugify(clean_text($data['slug'] ?? $name, 80));
    $template = clean_text($data['template_escolhido'] ?? 'classico', 40);
    if (!valid_template($template)) {
        $template = 'classico';
    }

    $slug = $slugBase;
    $suffix = 2;
    while (true) {
        $stmt = $pdo->prepare('SELECT id FROM revendedores WHERE slug = ? AND id <> ? LIMIT 1');
        $stmt->execute([$slug, $id]);
        if (!$stmt->fetch()) {
            break;
        }
        $slug = $slugBase . '-' . $suffix;
        $suffix++;
    }

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('
            UPDATE revendedores
            SET template_escolhido = ?,
                slug = ?,
                regras_aceitas_em = COALESCE(regras_aceitas_em, CURRENT_TIMESTAMP),
                termos_versao = ?,
                atualizado_em = CURRENT_TIMESTAMP
            WHERE id = ?
        ');
        $stmt->execute([$template, $slug, SYSTEM_TERMS_VERSION, $id]);

        $stmt = $pdo->prepare('
            INSERT INTO configuracoes_revendedor
                (user_id, nome_marca, pix, pix_tipo, pix_chave, pix_recebedor, pix_cidade, pix_instrucoes, comprovante_mensagem, dados_bancarios, checkout_url, preco, titulo_oferta, texto_oferta, texto_botao, depoimentos, cor_tema, logo, imagem_principal)
            VALUES
                (:user_id, :nome_marca, :pix, :pix_tipo, :pix_chave, :pix_recebedor, :pix_cidade, :pix_instrucoes, :comprovante_mensagem, :dados_bancarios, :checkout_url, :preco, :titulo_oferta, :texto_oferta, :texto_botao, :depoimentos, :cor_tema, :logo, :imagem_principal)
            ON CONFLICT(user_id) DO UPDATE SET
                nome_marca = excluded.nome_marca,
                pix = excluded.pix,
                pix_tipo = excluded.pix_tipo,
                pix_chave = excluded.pix_chave,
                pix_recebedor = excluded.pix_recebedor,
                pix_cidade = excluded.pix_cidade,
                pix_instrucoes = excluded.pix_instrucoes,
                comprovante_mensagem = excluded.comprovante_mensagem,
                dados_bancarios = excluded.dados_bancarios,
                checkout_url = excluded.checkout_url,
                preco = excluded.preco,
                titulo_oferta = excluded.titulo_oferta,
                texto_oferta = excluded.texto_oferta,
                texto_botao = excluded.texto_botao,
                depoimentos = excluded.depoimentos,
                cor_tema = excluded.cor_tema,
                logo = excluded.logo,
                imagem_principal = excluded.imagem_principal
        ');
        $stmt->execute([
            ':user_id' => $id,
            ':nome_marca' => $name,
            ':pix' => clean_text($data['pix_chave'] ?? $data['pix'] ?? '', 220),
            ':pix_tipo' => clean_text($data['pix_tipo'] ?? '', 40),
            ':pix_chave' => clean_text($data['pix_chave'] ?? '', 220),
            ':pix_recebedor' => clean_text($data['pix_recebedor'] ?? '', 160),
            ':pix_cidade' => clean_text($data['pix_cidade'] ?? '', 120),
            ':pix_instrucoes' => clean_multiline($data['pix_instrucoes'] ?? '', 1000),
            ':comprovante_mensagem' => clean_multiline($data['comprovante_mensagem'] ?? '', 1000),
            ':dados_bancarios' => clean_multiline($data['dados_bancarios'] ?? '', 1000),
            ':checkout_url' => '',
            ':preco' => clean_text($data['preco'] ?? '', 40),
            ':titulo_oferta' => clean_text($data['titulo_oferta'] ?? '', 180),
            ':texto_oferta' => clean_multiline($data['texto_oferta'] ?? '', 1200),
            ':texto_botao' => clean_text($data['texto_botao'] ?? '', 80),
            ':depoimentos' => clean_multiline($data['depoimentos'] ?? '', 2000),
            ':cor_tema' => preg_match('/^#[0-9a-fA-F]{6}$/', (string) ($data['cor_tema'] ?? '')) ? $data['cor_tema'] : '#16a34a',
            ':logo' => clean_text($data['logo'] ?? '', 500),
            ':imagem_principal' => clean_text($data['imagem_principal'] ?? '', 500),
        ]);

        $whatsappContato = clean_text($data['whatsapp_contato'] ?? '', 40);
        if ($whatsappContato !== '') {
            $stmt = $pdo->prepare('UPDATE revendedores SET whatsapp = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?');
            $stmt->execute([$whatsappContato, $id]);
        }
        $pdo->commit();
    } catch (Throwable $error) {
        $pdo->rollBack();
        json_response(['ok' => false, 'error' => 'Erro ao salvar dados do dono da página.'], 500);
    }

    json_response(['ok' => true, 'slug' => $slug, 'url' => public_origin() . '/p/' . $slug]);
}

if ($action === 'save_reseller_profile' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = require_reseller();
    $data = request_json();
    $name = clean_text($data['nome'] ?? '', 160);
    $whatsapp = clean_text($data['whatsapp'] ?? '', 40);

    if ($name === '' || $whatsapp === '') {
        json_response(['ok' => false, 'error' => 'Preencha nome e WhatsApp.'], 422);
    }

    $stmt = $pdo->prepare('UPDATE revendedores SET nome = ?, whatsapp = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?');
    $stmt->execute([$name, $whatsapp, $id]);
    json_response(['ok' => true]);
}

if ($action === 'save_invite_profile' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = require_reseller();
    $data = request_json();

    $publicName = clean_text($data['public_name'] ?? '', 120);
    $profilePhoto = clean_text($data['profile_photo'] ?? '', 500);
    $profileBio = clean_text($data['profile_bio'] ?? '', 180);
    $whatsappDigits = preg_replace('/\D+/', '', (string) ($data['whatsapp_contato'] ?? '')) ?: '';

    if ($profilePhoto !== '' && !filter_var($profilePhoto, FILTER_VALIDATE_URL) && !str_starts_with($profilePhoto, app_base_path() . '/')) {
        json_response(['ok' => false, 'error' => 'Informe uma URL válida para a foto de perfil.'], 422);
    }

    if ($whatsappDigits !== '' && (strlen($whatsappDigits) < 10 || strlen($whatsappDigits) > 15)) {
        json_response(['ok' => false, 'error' => 'Informe o WhatsApp somente com números, incluindo DDI/DDD quando necessário.'], 422);
    }

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('
            INSERT INTO configuracoes_revendedor (user_id, public_name, profile_photo, profile_bio)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                public_name = excluded.public_name,
                profile_photo = excluded.profile_photo,
                profile_bio = excluded.profile_bio
        ');
        $stmt->execute([$id, $publicName, $profilePhoto, $profileBio]);

        if ($whatsappDigits !== '') {
            $stmt = $pdo->prepare('UPDATE revendedores SET whatsapp = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ?');
            $stmt->execute([$whatsappDigits, $id]);
        }

        $pdo->commit();
    } catch (Throwable $error) {
        $pdo->rollBack();
        json_response(['ok' => false, 'error' => 'Erro ao salvar perfil de convite.'], 500);
    }

    json_response(['ok' => true]);
}

if ($action === 'logout') {
    unset($_SESSION['reseller_id']);
    json_response(['ok' => true]);
}

json_response(['ok' => false, 'error' => 'Ação pública inválida.'], 404);
