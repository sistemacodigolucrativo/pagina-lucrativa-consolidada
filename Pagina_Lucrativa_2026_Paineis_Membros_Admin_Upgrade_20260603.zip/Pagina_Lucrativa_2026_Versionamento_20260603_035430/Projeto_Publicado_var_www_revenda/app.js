const $ = (selector) => document.querySelector(selector);
const BASE_PATH = window.location.pathname.startsWith('/revenda') ? '/revenda' : '';
const appUrl = (path) => `${BASE_PATH}${path}`;
const isMemberAreaPage = document.body.classList.contains('member-page');

const setMessage = (selector, text, ok = true) => {
  const el = $(selector);
  if (!el) return;
  el.textContent = text;
  el.className = `form-message ${ok ? 'success' : 'error'}`;
};

const setText = (selector, text) => {
  const el = $(selector);
  if (el) el.textContent = text;
};

const setHref = (selector, href) => {
  const el = $(selector);
  if (el) el.href = href;
};

const setValue = (selector, value) => {
  const el = $(selector);
  if (el) el.value = value;
};

const escapeHtml = (value) => String(value ?? '')
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')
  .replace(/'/g, '&#039;');

const formatDateTime = (value) => {
  if (!value) return '-';
  const date = new Date(String(value).replace(' ', 'T'));
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' });
};

const isValidCheckoutEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || '').trim());
const isValidCheckoutWhatsapp = (whatsapp) => /^[1-9]{2}9\d{8}$/.test(String(whatsapp || '').trim());
const isValidReceiptFile = (file) => {
  if (!file) return false;
  const validTypes = ['image/jpeg', 'image/png'];
  const validExtensions = /\.(jpe?g|png)$/i;
  return validTypes.includes(file.type) || validExtensions.test(file.name || '');
};

const copyTextSafely = async (text) => {
  if (!text) return false;

  try {
    if (navigator.clipboard?.writeText && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (error) {
    // Fall through to the manual browser fallback below.
  }

  const textarea = document.createElement('textarea');
  textarea.value = text;
  textarea.setAttribute('readonly', '');
  textarea.style.position = 'fixed';
  textarea.style.top = '-9999px';
  textarea.style.left = '-9999px';
  document.body.appendChild(textarea);
  textarea.select();
  textarea.setSelectionRange(0, textarea.value.length);

  let copied = false;
  try {
    copied = document.execCommand('copy');
  } catch (error) {
    copied = false;
  }

  document.body.removeChild(textarea);
  return copied;
};

const selectPixKeyForManualCopy = () => {
  const pixKey = $('#checkoutPixKey');
  if (!pixKey) return;
  const selection = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(pixKey);
  selection?.removeAllRanges();
  selection?.addRange(range);
};

const globalTextTargets = {
  hero_eyebrow: ['.conversion-hero .hot-eyebrow'],
  hero_title: ['.conversion-hero h1'],
  hero_lead: ['.conversion-hero .hero-lead'],
  hero_cta: ['.conversion-hero .hero-actions .button.primary'],
  trust_1: ['.trust-strip span:nth-child(1)'],
  trust_2: ['.trust-strip span:nth-child(2)'],
  trust_3: ['.trust-strip span:nth-child(3)'],
  trust_4: ['.trust-strip span:nth-child(4)'],
  receive_label: ['.hero-offer-label'],
  receive_title: ['.conversion-card h2'],
  receive_item_1: ['.conversion-card .check-list li:nth-child(1)'],
  receive_item_2: ['.conversion-card .check-list li:nth-child(2)'],
  receive_item_3: ['.conversion-card .check-list li:nth-child(3)'],
  receive_item_4: ['.conversion-card .check-list li:nth-child(4)'],
  receive_item_5: ['.conversion-card .check-list li:nth-child(5)'],
  receive_item_6: ['.conversion-card .check-list li:nth-child(6)'],
  micro_warning: ['.micro-warning--standalone'],
  problem_eyebrow: ['#problema .eyebrow'],
  problem_title: ['#problema h2'],
  problem_text_1: ['#problema > div:first-child p:nth-of-type(1)'],
  problem_text_2: ['#problema > div:first-child p:nth-of-type(2)'],
  problem_card_1_title: ['.pain-stack article:nth-of-type(1) b'],
  problem_card_1_text: ['.pain-stack article:nth-of-type(1) span'],
  problem_card_2_title: ['.pain-stack article:nth-of-type(2) b'],
  problem_card_2_text: ['.pain-stack article:nth-of-type(2) span'],
  problem_card_3_title: ['.pain-stack article:nth-of-type(3) b'],
  problem_card_3_text: ['.pain-stack article:nth-of-type(3) span'],
  testimonials_eyebrow: ['#depoimentos .eyebrow'],
  testimonials_title: ['#depoimentos .section-head h2'],
  testimonials_text: ['#depoimentos .section-head p'],
  how_eyebrow: ['#como-funciona .eyebrow'],
  how_title: ['#como-funciona .section-head h2'],
  how_text: ['#como-funciona .section-head p'],
  how_step_1_title: ['.timeline-conversion article:nth-child(1) h3'],
  how_step_1_text: ['.timeline-conversion article:nth-child(1) p'],
  how_step_2_title: ['.timeline-conversion article:nth-child(2) h3'],
  how_step_2_text: ['.timeline-conversion article:nth-child(2) p'],
  how_step_3_title: ['.timeline-conversion article:nth-child(3) h3'],
  how_step_3_text: ['.timeline-conversion article:nth-child(3) p'],
  how_step_4_title: ['.timeline-conversion article:nth-child(4) h3'],
  how_step_4_text: ['.timeline-conversion article:nth-child(4) p'],
  how_step_5_title: ['.timeline-conversion article:nth-child(5) h3'],
  how_step_5_text: ['.timeline-conversion article:nth-child(5) p'],
  customize_eyebrow: ['#personalizar .eyebrow'],
  customize_title: ['#personalizar > div:first-child h2'],
  customize_text: ['#personalizar > div:first-child > p'],
  customize_cta: ['#personalizar .hero-actions .button.primary'],
  feature_1_title: ['.feature-stack article:nth-child(1) b'],
  feature_1_text: ['.feature-stack article:nth-child(1) span'],
  feature_2_title: ['.feature-stack article:nth-child(2) b'],
  feature_2_text: ['.feature-stack article:nth-child(2) span'],
  feature_3_title: ['.feature-stack article:nth-child(3) b'],
  feature_3_text: ['.feature-stack article:nth-child(3) span'],
  feature_4_title: ['.feature-stack article:nth-child(4) b'],
  feature_4_text: ['.feature-stack article:nth-child(4) span'],
  feature_5_title: ['.feature-stack article:nth-child(5) b'],
  feature_5_text: ['.feature-stack article:nth-child(5) span'],
  feature_6_title: ['.feature-stack article:nth-child(6) b'],
  feature_6_text: ['.feature-stack article:nth-child(6) span'],
  opportunity_eyebrow: ['.greed-safe-section .eyebrow'],
  opportunity_title: ['.greed-safe-section .section-head h2'],
  opportunity_text: ['.greed-safe-section .section-head p'],
  opportunity_1_title: ['.opportunity-grid article:nth-child(1) b'],
  opportunity_1_text: ['.opportunity-grid article:nth-child(1) p'],
  opportunity_2_title: ['.opportunity-grid article:nth-child(2) b'],
  opportunity_2_text: ['.opportunity-grid article:nth-child(2) p'],
  opportunity_3_title: ['.opportunity-grid article:nth-child(3) b'],
  opportunity_3_text: ['.opportunity-grid article:nth-child(3) p'],
  opportunity_4_title: ['.opportunity-grid article:nth-child(4) b'],
  opportunity_4_text: ['.opportunity-grid article:nth-child(4) p'],
  models_eyebrow: ['#modelos .eyebrow'],
  models_title: ['#modelos .section-head h2'],
  models_text: ['#modelos .section-head p:not(.swipe-hint)'],
  models_hint: ['#modelos .swipe-hint'],
  checkout_eyebrow: ['#comprovante .checkout-summary .eyebrow'],
  checkout_help_title: ['.scarcity-box b'],
  checkout_help_text: ['.scarcity-box p'],
  checkout_card_eyebrow: ['.checkout-card-head .eyebrow'],
  checkout_card_title: ['.checkout-card-head h3'],
  checkout_badge: ['.checkout-card-head .checkout-badge'],
  checkout_submit: ['.checkout-submit'],
  unlock_eyebrow: ['#desbloquear .eyebrow'],
  unlock_title: ['#desbloquear .section-head h2'],
  unlock_text: ['#desbloquear .section-head p'],
  unlock_button: ['#unlockForm button[type="submit"]'],
  rules_eyebrow: ['#regras .eyebrow'],
  rules_title: ['#regras .section-head h2'],
  rules_text: ['#regras .section-head p'],
  rules_item_1: ['#regras .status-list span:nth-child(1)'],
  rules_item_2: ['#regras .status-list span:nth-child(2)'],
  rules_item_3: ['#regras .status-list span:nth-child(3)'],
  rules_item_4: ['#regras .status-list span:nth-child(4)'],
  rules_card_title: ['#regras .rules-card b'],
  rules_card_text: ['#regras .rules-card p'],
  final_eyebrow: ['.final-cta .eyebrow'],
  final_title: ['.final-cta h2'],
  final_text: ['.final-cta > p'],
  final_primary_cta: ['.final-cta .hero-actions .button.primary'],
  final_secondary_cta: ['.final-cta .hero-actions .button.ghost'],
  sticky_cta: ['.sticky-mobile-cta'],
  footer_copyright: ['.footer p:nth-child(1)'],
  footer_subtitle: ['.footer p:nth-child(2)'],
};

const applyGlobalTexts = (texts) => {
  Object.entries(texts || {}).forEach(([key, value]) => {
    const selectors = globalTextTargets[key] || [];
    selectors.forEach((selector) => {
      document.querySelectorAll(selector).forEach((el) => {
        el.textContent = value;
      });
    });
  });
};

const loadGlobalTexts = async () => {
  try {
    const response = await fetch(appUrl('/api/public.php?action=global_texts'));
    if (!response.ok) return;
    const data = await response.json();
    if (data.ok && data.texts) applyGlobalTexts(data.texts);
  } catch (error) {
    // The page keeps the static fallback copy if the API is unavailable.
  }
};

const postJson = async (url, payload) => {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await response.json();
  if (!response.ok || !data.ok) throw new Error(data.error || 'Erro inesperado.');
  return data;
};

const fillForm = (form, data) => {
  if (!form) return;
  [...form.elements].forEach((field) => {
    if (!field.name || data[field.name] === undefined || data[field.name] === null) return;
    if (field.type === 'checkbox') {
      field.checked = Boolean(data[field.name]);
      return;
    }
    field.value = data[field.name];
  });
};

const testimonialItems = [
  { name: 'Mariana Alves', meta: 'Página configurada pelo celular', text: 'Eu gostei porque consegui explicar a oportunidade com um link só, sem ficar repetindo tudo em várias mensagens.' },
  { name: 'Carlos Henrique', meta: 'Uso pelo WhatsApp', text: 'O que mais ajudou foi ter PIX, contato e apresentação no mesmo lugar. Fica mais fácil mandar para quem pergunta.' },
  { name: 'Patrícia Lima', meta: 'Área de Membros', text: 'Achei simples trocar os dados e deixar a página com meu nome. Não precisei mexer com parte técnica.' },
  { name: 'Roberto Nunes', meta: 'Link personalizado', text: 'Antes eu explicava tudo no improviso. Agora envio o link e a pessoa já entende o caminho.' },
  { name: 'Fernanda Costa', meta: 'Divulgação pelo Instagram', text: 'Usei na bio e ficou mais profissional do que mandar só texto solto no direct.' },
  { name: 'Diego Martins', meta: 'Página própria', text: 'A página deixa claro o que a pessoa precisa fazer, como pagar e como falar comigo.' },
  { name: 'Luciana Rocha', meta: 'PIX organizado', text: 'Ter as instruções de pagamento visíveis ajuda muito. A pessoa não fica perdida procurando informação.' },
  { name: 'André Souza', meta: 'Configuração rápida', text: 'Consegui ajustar nome, WhatsApp, preço e texto sem depender de ninguém.' },
  { name: 'Camila Pereira', meta: 'Mais clareza', text: 'O link passa mais confiança do que explicar tudo em áudio ou mensagem quebrada.' },
  { name: 'Eduardo Ribeiro', meta: 'Divulgação em grupos', text: 'Ficou melhor para divulgar em grupos, porque a página já organiza a apresentação.' },
  { name: 'Renata Moreira', meta: 'Atendimento', text: 'Quando a pessoa chama no WhatsApp, ela já chega com mais contexto sobre o que viu.' },
  { name: 'João Batista', meta: 'Modelo visual', text: 'Gostei de poder escolher o visual e deixar a página mais combinando com minha forma de divulgar.' },
  { name: 'Aline Campos', meta: 'Uso no celular', text: 'No celular ficou fácil de abrir, copiar o link e mandar para outras pessoas.' },
  { name: 'Marcelo Vieira', meta: 'Apresentação', text: 'A estrutura ajuda a mostrar a oportunidade de forma mais organizada e direta.' },
  { name: 'Simone Freitas', meta: 'Sem começar do zero', text: 'Eu não saberia montar uma página sozinha. Ter a estrutura pronta facilitou bastante.' },
  { name: 'Rafael Gomes', meta: 'Dados em um lugar', text: 'Nome, contato, PIX e instruções juntos deixam tudo mais claro para quem acessa.' },
  { name: 'Vanessa Cardoso', meta: 'Mensagem mais profissional', text: 'Senti que o link deixa a divulgação mais séria do que mandar explicação longa.' },
  { name: 'Tiago Barros', meta: 'Rotina de divulgação', text: 'Consigo usar o mesmo link em status, bio e conversas sem refazer a explicação.' },
  { name: 'Priscila Duarte', meta: 'Página objetiva', text: 'A pessoa entra e já vê a proposta, o contato e o caminho para seguir.' },
  { name: 'Gustavo Melo', meta: 'WhatsApp em destaque', text: 'O botão de WhatsApp ajuda porque a conversa começa mais rápido.' },
  { name: 'Helena Martins', meta: 'Configuração simples', text: 'Gostei da área de membros porque é direta. Entrei, editei os dados e salvei.' },
  { name: 'Bruno Azevedo', meta: 'Organização', text: 'Antes eu esquecia informação importante. A página serve como uma apresentação completa.' },
  { name: 'Juliana Farias', meta: 'Compartilhamento', text: 'É mais fácil compartilhar um link pronto do que ficar montando texto toda vez.' },
  { name: 'Leandro Matos', meta: 'PIX e contato', text: 'O visitante encontra rapidamente como pagar e como mandar mensagem.' },
  { name: 'Marta Oliveira', meta: 'Página de apresentação', text: 'A página me ajudou a deixar a oportunidade mais clara para quem ainda não conhece.' },
  { name: 'Sérgio Almeida', meta: 'Menos improviso', text: 'Com a página pronta, parei de depender de explicação improvisada.' },
  { name: 'Bianca Lopes', meta: 'Visual atualizado', text: 'O visual atual passa mais confiança do que modelos antigos que eu já tinha visto.' },
  { name: 'Paulo César', meta: 'Link próprio', text: 'Ter um link com minha página deixa a divulgação mais organizada.' },
  { name: 'Natália Ramos', meta: 'Dúvidas reduzidas', text: 'A pessoa já entende melhor antes de chamar, então a conversa fica mais objetiva.' },
  { name: 'Wesley Rocha', meta: 'Controle dos dados', text: 'Posso alterar preço, texto e contato quando preciso, sem depender de suporte.' },
  { name: 'Carolina Mendes', meta: 'Bio do Instagram', text: 'Coloquei o link na bio e ficou mais fácil direcionar interessados.' },
  { name: 'Fábio Santana', meta: 'Apresentação clara', text: 'A página ajuda a mostrar a oportunidade com começo, meio e chamada para ação.' },
  { name: 'Elaine Castro', meta: 'Mais confiança', text: 'Quando envio a página, sinto que a pessoa recebe algo mais organizado.' },
  { name: 'Rodrigo Lima', meta: 'Uso diário', text: 'O link virou meu material principal para divulgar sem perder tempo.' },
  { name: 'Daniela Reis', meta: 'Área simples', text: 'A edição é simples e os campos principais já estão no lugar certo.' },
  { name: 'Alexandre Pinto', meta: 'Celular e computador', text: 'Abriu bem tanto no celular quanto no notebook, o que ajuda na divulgação.' },
  { name: 'Márcia Teixeira', meta: 'Instruções claras', text: 'As instruções deixam claro o próximo passo para quem quer continuar.' },
  { name: 'Renan Carvalho', meta: 'Contato direto', text: 'O WhatsApp na página facilita o atendimento depois que a pessoa acessa.' },
  { name: 'Débora Martins', meta: 'Sem parte técnica', text: 'Gostei porque eu só preenchi meus dados e usei o link.' },
  { name: 'Felipe Moraes', meta: 'Página pronta', text: 'A estrutura pronta economiza tempo e evita deixar informação importante de fora.' },
  { name: 'Isabela Cunha', meta: 'Clareza na oferta', text: 'O texto organizado ajuda a pessoa entender a proposta antes de perguntar.' },
  { name: 'Maurício Lopes', meta: 'Divulgação constante', text: 'Uso o link em conversas e status, sempre com a mesma apresentação.' },
  { name: 'Lívia Santos', meta: 'Visual profissional', text: 'O visual da página deixa a oportunidade mais apresentável.' },
  { name: 'César Augusto', meta: 'Pagamento visível', text: 'O PIX visível e as instruções reduzem confusão na hora de orientar interessados.' },
  { name: 'Talita Ferreira', meta: 'Organização do contato', text: 'A pessoa já encontra meu WhatsApp e entende como falar comigo.' },
  { name: 'Igor Nascimento', meta: 'Fluxo simples', text: 'O fluxo fica simples: acessar, ler, entender e entrar em contato.' },
  { name: 'Letícia Andrade', meta: 'Sem retrabalho', text: 'Não preciso escrever a mesma explicação toda hora. O link faz essa parte.' },
  { name: 'Samuel Corrêa', meta: 'Modelo editável', text: 'Poder mudar os dados depois dá mais controle sobre a página.' },
  { name: 'Patrícia Gonçalves', meta: 'Apresentação mobile', text: 'No celular a página fica clara e fácil de enviar para outras pessoas.' },
  { name: 'Vinícius Araújo', meta: 'Página própria', text: 'O principal é ter uma página própria para apresentar a Página Lucrativa com meus dados.' },
];

const setupTestimonialCarousel = () => {
  const carousel = $('.testimonial-carousel');
  if (!carousel) return;

  const textEl = carousel.querySelector('[data-testimonial-text]');
  const nameEl = carousel.querySelector('[data-testimonial-name]');
  const metaEl = carousel.querySelector('[data-testimonial-meta]');
  const avatarEl = carousel.querySelector('[data-testimonial-avatar]');
  const card = carousel.querySelector('[data-testimonial-card]');
  const status = $('[data-testimonial-status]');
  const nextButtons = carousel.querySelectorAll('[data-testimonial-next], [data-testimonial-prev]');
  const sessionKey = 'paginaLucrativaTestimonialsSeenV1';
  const desktopAutoDelay = 5000;
  const mobileAutoDelay = 6000;
  const transitionDelay = 500;
  const contentSwapDelay = 250;
  const pauseDelay = 15000;
  let timer = null;
  let pauseUntil = 0;
  let isInteracting = false;
  let isSwitching = false;
  let startX = 0;
  let seen = [];

  const getAutoDelay = () => (
    window.matchMedia('(max-width: 620px)').matches ? mobileAutoDelay : desktopAutoDelay
  );

  try {
    seen = JSON.parse(sessionStorage.getItem(sessionKey) || '[]');
  } catch (error) {
    seen = [];
  }

  const saveSeen = () => {
    try {
      sessionStorage.setItem(sessionKey, JSON.stringify(seen));
    } catch (error) {
      // sessionStorage may be unavailable in restricted browsers.
    }
  };

  const pickRandomUnseen = () => {
    if (seen.length >= testimonialItems.length) {
      seen = [];
    }
    const available = testimonialItems
      .map((_, index) => index)
      .filter((index) => !seen.includes(index));
    const index = available[Math.floor(Math.random() * available.length)];
    seen.push(index);
    saveSeen();
    return testimonialItems[index];
  };

  const showNextTestimonial = () => {
    const item = pickRandomUnseen();
    const initials = item.name
      .split(' ')
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part.charAt(0))
      .join('')
      .toUpperCase();
    textEl.textContent = `“${item.text}”`;
    nameEl.textContent = item.name;
    metaEl.textContent = item.meta;
    if (avatarEl) avatarEl.textContent = initials;
    if (status) status.textContent = 'Passe o dedo para deslizar entre os depoimentos';
  };

  const switchTestimonial = (withTransition = true) => {
    if (!withTransition || isSwitching) {
      showNextTestimonial();
      return;
    }

    isSwitching = true;
    card?.classList.add('is-switching');

    setTimeout(() => {
      showNextTestimonial();
      card?.classList.remove('is-switching');
      setTimeout(() => {
        isSwitching = false;
      }, transitionDelay);
    }, contentSwapDelay);
  };

  const scheduleAuto = (delay = getAutoDelay()) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      const remainingPause = pauseUntil - Date.now();
      if (isInteracting || remainingPause > 0) {
        scheduleAuto(Math.max(250, remainingPause || pauseDelay));
        return;
      }
      switchTestimonial();
      scheduleAuto(getAutoDelay());
    }, delay);
  };

  const pauseAuto = () => {
    pauseUntil = Date.now() + pauseDelay;
    if (status) status.textContent = 'Carrossel pausado por 15 segundos.';
    scheduleAuto(pauseDelay);
  };

  nextButtons.forEach((button) => {
    button.addEventListener('click', () => {
      pauseAuto();
      switchTestimonial();
    });
  });

  carousel.addEventListener('mouseenter', pauseAuto);
  carousel.addEventListener('click', pauseAuto);
  carousel.addEventListener('touchstart', pauseAuto, { passive: true });

  card?.addEventListener('pointerdown', (event) => {
    isInteracting = true;
    startX = event.clientX;
    pauseAuto();
  });

  card?.addEventListener('pointerup', (event) => {
    const distance = event.clientX - startX;
    isInteracting = false;
    pauseAuto();
    if (Math.abs(distance) > 35) {
      switchTestimonial();
    }
  });

  card?.addEventListener('pointercancel', () => {
    isInteracting = false;
    pauseAuto();
  });

  card?.addEventListener('click', pauseAuto);
  card?.addEventListener('focusin', pauseAuto);

  showNextTestimonial();
  scheduleAuto(getAutoDelay());
};

let currentPixKey = '';
let currentPublicLink = '';
let pendingCheckoutTarget = '';

const ownerTabMap = {
  overview: '#ownerOverview',
  config: '#ownerConfig',
  appearance: '#ownerAppearance',
  payment: '#ownerPayment',
  invite: '#ownerInvite',
  testimonials: '#ownerTestimonials',
  share: '#ownerShare',
  checklist: '#ownerChecklistPanel',
  materials: '#ownerMaterials',
  support: '#ownerSupport',
  profile: '#ownerProfile',
  rules: '#ownerRules',
};

const ownerFormTabs = new Set(['config', 'appearance', 'payment', 'testimonials']);

const setOwnerTab = (tab) => {
  const safeTab = ownerTabMap[tab] ? tab : 'overview';
  document.querySelectorAll('[data-owner-tab]').forEach((button) => {
    const isActive = button.dataset.ownerTab === safeTab;
    button.classList.toggle('active', isActive);
    button.setAttribute('aria-current', isActive ? 'page' : 'false');
  });

  Object.entries(ownerTabMap).forEach(([key, selector]) => {
    const panel = $(selector);
    if (panel) panel.classList.toggle('hidden', key !== safeTab);
  });

  $('#resellerForm')?.classList.toggle('hidden', !ownerFormTabs.has(safeTab));
  $('[data-member-menu]')?.classList.remove('is-open');
  $('[data-member-menu-toggle]')?.setAttribute('aria-expanded', 'false');
};

const copyCurrentPublicLink = async (messageSelector = '#ownerCopyMessage') => {
  if (!currentPublicLink) {
    setMessage(messageSelector, 'Salve os dados para gerar o link antes de copiar.', false);
    return;
  }

  const copied = await copyTextSafely(currentPublicLink);
  setMessage(messageSelector, copied ? 'Link copiado.' : 'Link selecionado. Use Ctrl+C ou toque e segure para copiar.', copied);
};

const buildShareText = (reseller, url) => {
  const pageName = reseller.nome_marca || reseller.public_name || reseller.nome || 'minha Página Lucrativa';
  if (!url) return 'Configure sua página e salve os dados para gerar seu link de divulgação.';
  return `Conheça ${pageName}. Acesse o link para ver a apresentação completa: ${url}`;
};

const renderChecklistItems = (items, target, options = {}) => {
  const checklist = $(target);
  if (!checklist) return;
  const visibleItems = options.limit ? items.slice(0, options.limit) : items;
  checklist.innerHTML = visibleItems.map((item) => `
    <article class="${item.done ? 'is-done' : 'is-pending'}">
      <span>${item.done ? '✓' : '!'}</span>
      <b>${escapeHtml(item.label)}</b>
      <button type="button" data-owner-tab="${escapeHtml(item.tab)}">${item.done ? 'Revisar' : 'Corrigir agora'}</button>
    </article>
  `).join('');
};

const renderMemberTestimonialsPreview = (value) => {
  const preview = $('#testimonialPreviewList');
  if (!preview) return;
  const testimonials = String(value || '')
    .split(/\r?\n/)
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 3);

  if (!testimonials.length) {
    preview.innerHTML = '<p class="muted-note">Nenhum depoimento cadastrado ainda.</p>';
    return;
  }

  preview.innerHTML = testimonials.map((text, index) => `
    <article>
      <div><strong>Depoimento ${index + 1}</strong><span>★★★★★</span></div>
      <p>${escapeHtml(text)}</p>
    </article>
  `).join('');
};

const syncModalLock = () => {
  const hasOpenModal = Boolean($('.checkout-rules-modal.is-open') || $('.checkout-modal.is-open'));
  document.body.classList.toggle('modal-lock', hasOpenModal);
};

const setCheckoutModalOpen = (open) => {
  const checkout = $('#comprovante.checkout-modal');
  if (!checkout) return false;
  checkout.classList.toggle('is-open', open);
  checkout.setAttribute('aria-hidden', String(!open));
  syncModalLock();
  return true;
};

const ensureCheckoutRulesModal = () => {
  let modal = $('#checkoutRulesModal');
  if (modal) return modal;

  document.body.insertAdjacentHTML('beforeend', `
    <div class="checkout-rules-modal" id="checkoutRulesModal" aria-hidden="true">
      <div class="checkout-rules-modal__backdrop" data-rules-close></div>
      <section class="checkout-rules-modal__panel" role="dialog" aria-modal="true" aria-labelledby="checkoutRulesTitle">
        <button class="checkout-rules-modal__close" type="button" aria-label="Fechar regras" data-rules-close>×</button>
        <span class="eyebrow">Regras de uso</span>
        <h2 id="checkoutRulesTitle">Regras simples para manter sua página sempre ativa.</h2>
        <p>Use sua página com clareza, ética e dados verdadeiros. Assim sua estrutura continua ativa e confiável.</p>
        <div class="status-list checkout-rules-modal__list">
          <span>use dados verdadeiros e completos</span>
          <span>divulgue com clareza e ética</span>
          <span>não faça promessas falsas</span>
          <span>sem spam ou mensagens abusivas</span>
        </div>
        <div class="rules-card checkout-rules-modal__important">
          <b>Importante</b>
          <p>Essa é a estrutura pronta para você; o sucesso vem da sua dedicação e da forma como se comunica.</p>
        </div>
        <div class="hero-actions checkout-rules-modal__actions">
          <button class="button primary" type="button" data-rules-accept>Li e quero acessar o checkout</button>
          <button class="button ghost" type="button" data-rules-close>Voltar</button>
        </div>
      </section>
    </div>
  `);

  modal = $('#checkoutRulesModal');
  return modal;
};

const setCheckoutRulesOpen = (open) => {
  const modal = ensureCheckoutRulesModal();
  modal.classList.toggle('is-open', open);
  modal.setAttribute('aria-hidden', String(!open));
  syncModalLock();
};

const goToCheckoutTarget = () => {
  const target = pendingCheckoutTarget || '#comprovante';
  pendingCheckoutTarget = '';
  setCheckoutRulesOpen(false);

  if ((target === '#comprovante' || target.endsWith('/revenda/#comprovante')) && setCheckoutModalOpen(true)) {
    return;
  }

  if (target.endsWith('/revenda/#comprovante')) {
    sessionStorage.setItem('checkoutRulesAccepted', '1');
  }
  location.href = target;
};

const loadCheckout = async () => {
  const response = await fetch(appUrl('/api/public.php?action=checkout_config'));
  if (!response.ok) return;
  const data = await response.json();
  if (!data.ok || !data.checkout) return;
  if (!$('#checkoutTitle')) return;

  const checkout = data.checkout;
  currentPixKey = checkout.pix_key || '';
  setText('#checkoutTitle', checkout.title || 'Ative AGORA por apenas R$ 10,00');
  setText('#checkoutPrice', checkout.price || 'R$ 10,00');
  setValue('#orderAmount', checkout.price || 'R$ 10,00');
  setText('#checkoutNote', checkout.note || 'Acesso por valor único, sem mensalidade, enquanto as regras de uso forem respeitadas.');
  setText('#checkoutPixType', checkout.pix_type || 'Chave PIX');
  setText('#checkoutPixKey', currentPixKey || 'Chave PIX ainda não configurada');
  setText('#checkoutPixReceiver', `Recebedor: ${checkout.pix_receiver || 'Página Lucrativa 2026'}`);
  setText('#checkoutPixInstructions', checkout.pix_instructions || 'Copie a chave PIX, pague R$ 10,00 e envie o comprovante com seus dados para liberar o acesso.');
  const copyPixBtn = $('#copyPixBtn');
  if (copyPixBtn) copyPixBtn.disabled = !currentPixKey;
};

const loadTemplates = async () => {
  const response = await fetch(appUrl('/api/public.php?action=templates'));
  const data = await response.json();
  const select = $('#templateSelect');
  if (!select || !data.ok) return;
  select.innerHTML = data.templates.map((template) => (
    `<option value="${template.id}">${template.name}</option>`
  )).join('');
};

const updateOwnerDashboard = (reseller, origin) => {
  const url = reseller.slug ? `${origin}/p/${reseller.slug}` : '';
  currentPublicLink = url;
  const name = reseller.nome || reseller.public_name || 'Membro';
  const pageName = reseller.nome_marca || reseller.public_name || `Página de ${name}`;
  const status = reseller.status || 'pendente';
  const template = reseller.template_escolhido || 'classico';
  const price = reseller.preco || 'não definido';
  const whatsapp = reseller.whatsapp_contato || reseller.whatsapp || '';
  const pix = reseller.pix_chave || reseller.pix || '';
  const hasOffer = Boolean((reseller.titulo_oferta || '').trim() && (reseller.texto_oferta || '').trim());
  const hasRules = Boolean(reseller.regras_aceitas_em);
  const shareText = buildShareText(reseller, url);
  const shareUrl = url ? `https://wa.me/?text=${encodeURIComponent(shareText)}` : '#';

  const checklistItems = [
    { label: 'Nome da página preenchido', done: Boolean((reseller.nome_marca || '').trim()), tab: 'config' },
    { label: 'WhatsApp configurado', done: Boolean(String(whatsapp).trim()), tab: 'invite' },
    { label: 'PIX configurado', done: Boolean(String(pix).trim()), tab: 'payment' },
    { label: 'Modelo escolhido', done: Boolean(String(template).trim()), tab: 'appearance' },
    { label: 'Oferta preenchida', done: hasOffer, tab: 'config' },
    { label: 'Depoimentos revisados', done: Boolean((reseller.depoimentos || '').trim()), tab: 'testimonials' },
    { label: 'Regras aceitas', done: hasRules, tab: 'rules' },
    { label: 'Link gerado', done: Boolean(url), tab: 'share' },
  ];
  const completed = checklistItems.filter((item) => item.done).length;
  const percent = Math.round((completed / checklistItems.length) * 100);

  setText('#ownerStatusBadge', status);
  setText('#memberTopStatus', status);
  setText('#dashboardGreeting', `Olá, ${name}.`);
  setText('#dashboardProgressText', `Sua Página Lucrativa está ${percent}% configurada.`);
  setText('#dashboardProgressPercent', `${percent}%`);
  setText('#dashboardChecklistTitle', percent === 100 ? 'Sua página está pronta para divulgação.' : 'Falta pouco para publicar sua página.');
  setText('#ownerMetricStatus', status);
  setText('#ownerMetricTemplate', template);
  setText('#ownerMetricPrice', price);
  setText('#ownerMetricUpdated', formatDateTime(reseller.atualizado_em || reseller.criado_em));
  setText('#ownerPrimaryLink', url || 'Salve os dados para gerar o link.');
  setHref('#ownerPrimaryLink', url || '#');
  setHref('#previewPublicLinkBtn', url || '#');
  setHref('#memberTopOpenBtn', url || '#');
  setHref('#shareOpenPublicLinkBtn', url || '#');
  setHref('#dashboardShareWhatsAppBtn', shareUrl);
  setHref('#shareWhatsAppBtn', shareUrl);
  setValue('#shareMessageText', shareText);
  setText('#memberPreviewName', pageName);
  setText('#memberPreviewModel', `Modelo ${template}`);
  setText('#appearancePreviewName', pageName);
  setText('#appearancePreviewModel', `Modelo ${template}`);
  setText('#memberPreviewTitle', reseller.titulo_oferta || 'Título da oferta ainda não configurado');
  setText('#memberPreviewText', reseller.texto_oferta || 'Preencha sua oferta para visualizar uma prévia mais completa.');
  setText('#memberPreviewPrice', price);
  const progressBar = $('#dashboardProgressBar');
  if (progressBar) progressBar.style.width = `${percent}%`;

  renderChecklistItems(checklistItems, '#ownerChecklist', { limit: 4 });
  renderChecklistItems(checklistItems, '#ownerChecklistFull');
  renderMemberTestimonialsPreview(reseller.depoimentos);

  if (url) {
    $('#publicLinkBox')?.classList.remove('hidden');
    setText('#publicLink', url);
    setHref('#publicLink', url);
  } else {
    $('#publicLinkBox')?.classList.add('hidden');
    setText('#publicLink', '');
    setHref('#publicLink', '#');
  }
};

const loadReseller = async () => {
  const ownerPanel = $('#dono-pagina');
  if (!ownerPanel) return;

  const response = await fetch(appUrl('/api/public.php?action=reseller_me'));
  if (!response.ok) return;
  const data = await response.json();
  if (!data.ok) return;
  ownerPanel.classList.remove('hidden');
  $('#desbloquear')?.classList.add('hidden');
  setText('#resellerIntro', `Área de Membros ativa para ${data.reseller.nome} (${data.reseller.email}).`);
  const formData = { ...data.reseller, aceite_regras: Boolean(data.reseller.regras_aceitas_em) };
  fillForm($('#resellerForm'), formData);
  fillForm($('#resellerProfileForm'), data.reseller);
  fillForm($('#inviteProfileForm'), data.reseller);
  updateOwnerDashboard(data.reseller, data.origin);
};

$('#orderForm')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const email = form.elements.email?.value || '';
  const whatsapp = form.elements.whatsapp?.value || '';
  const receipt = form.elements.comprovante?.files?.[0] || null;

  if (!currentPixKey) {
    setMessage('#orderMessage', 'A chave PIX ainda não foi configurada para esta ativação.', false);
    return;
  }
  if (!isValidCheckoutEmail(email)) {
    setMessage('#orderMessage', 'E-mail inválido.', false);
    form.elements.email?.focus();
    return;
  }
  if (!isValidCheckoutWhatsapp(whatsapp)) {
    setMessage('#orderMessage', 'WhatsApp inválido. Use apenas números com DDD e celular, exemplo: 11999999999.', false);
    form.elements.whatsapp?.focus();
    return;
  }
  if (!isValidReceiptFile(receipt)) {
    setMessage('#orderMessage', 'Comprovante inválido. Envie apenas JPG, JPEG ou PNG.', false);
    form.elements.comprovante?.focus();
    return;
  }
  setMessage('#orderMessage', 'Enviando comprovante...');
  try {
    const response = await fetch(appUrl('/api/public.php?action=create_order'), {
      method: 'POST',
      body: new FormData(form),
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || 'Falha no envio.');
    form.reset();
    setMessage('#orderMessage', data.message || 'Comprovante enviado.');
  } catch (error) {
    setMessage('#orderMessage', error.message, false);
  }
});

$('#copyPixBtn')?.addEventListener('click', async () => {
  if (!currentPixKey) {
    setMessage('#pixCopyMessage', 'A chave PIX ainda não foi configurada.', false);
    return;
  }
  try {
    const copied = await copyTextSafely(currentPixKey);
    if (copied) {
      setMessage('#pixCopyMessage', 'Chave PIX copiada.');
      return;
    }
    selectPixKeyForManualCopy();
    setMessage('#pixCopyMessage', 'Chave PIX selecionada. Use Ctrl+C ou toque e segure para copiar.');
  } catch (error) {
    selectPixKeyForManualCopy();
    setMessage('#pixCopyMessage', 'Chave PIX selecionada. Use Ctrl+C ou toque e segure para copiar.');
  }
});

$('#unlockForm')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  setMessage('#unlockMessage', 'Validando chave...');
  try {
    await postJson(appUrl('/api/public.php?action=unlock'), {
      email: form.email.value,
      chave: form.chave.value,
    });
    setMessage('#unlockMessage', 'Acesso liberado.');
    if (!isMemberAreaPage) {
      location.href = appUrl('/membros/#dono-pagina');
      return;
    }
    await loadTemplates();
    await loadReseller();
    location.hash = '#dono-pagina';
  } catch (error) {
    setMessage('#unlockMessage', error.message, false);
  }
});

$('#resellerForm')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = Object.fromEntries(new FormData(form).entries());
  setMessage('#resellerMessage', 'Salvando...');
  try {
    await postJson(appUrl('/api/public.php?action=save_reseller'), payload);
    await loadReseller();
    setMessage('#resellerMessage', 'Dados salvos e link gerado.');
  } catch (error) {
    setMessage('#resellerMessage', error.message, false);
  }
});

document.addEventListener('click', async (event) => {
  const target = event.target;
  if (!(target instanceof HTMLElement)) return;

  const checkoutLink = target.closest('a[href="#comprovante"], a[href="/revenda/#comprovante"]');
  if (checkoutLink instanceof HTMLAnchorElement) {
    event.preventDefault();
    pendingCheckoutTarget = checkoutLink.getAttribute('href') || '#comprovante';
    setCheckoutRulesOpen(true);
    return;
  }

  if (target.closest('[data-rules-close]')) {
    event.preventDefault();
    setCheckoutRulesOpen(false);
    return;
  }

  if (target.closest('[data-rules-accept]')) {
    event.preventDefault();
    goToCheckoutTarget();
    return;
  }

  if (target.closest('[data-checkout-close]')) {
    event.preventDefault();
    setCheckoutModalOpen(false);
    return;
  }

  const copyPublicLinkButton = target.closest('[data-copy-public-link]');
  if (copyPublicLinkButton) {
    event.preventDefault();
    await copyCurrentPublicLink(copyPublicLinkButton.dataset.copyMessage || '#ownerCopyMessage');
    return;
  }

  const memberMenuToggle = target.closest('[data-member-menu-toggle]');
  if (memberMenuToggle) {
    const menu = $('[data-member-menu]');
    const isOpen = !menu?.classList.contains('is-open');
    menu?.classList.toggle('is-open', isOpen);
    memberMenuToggle.setAttribute('aria-expanded', String(isOpen));
    return;
  }

  const ownerTabButton = target.closest('[data-owner-tab]');
  if (ownerTabButton) {
    event.preventDefault();
    setOwnerTab(ownerTabButton.dataset.ownerTab);
  }
});

document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape') return;
  setCheckoutRulesOpen(false);
  setCheckoutModalOpen(false);
});

$('#inviteProfileForm')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  setMessage('#inviteProfileMessage', 'Salvando perfil de convite...');
  try {
    await postJson(appUrl('/api/public.php?action=save_invite_profile'), {
      public_name: form.elements.public_name.value,
      profile_photo: form.elements.profile_photo.value,
      profile_bio: form.elements.profile_bio.value,
      whatsapp_contato: form.elements.whatsapp_contato.value,
    });
    setMessage('#inviteProfileMessage', 'Perfil de convite salvo.');
  } catch (error) {
    setMessage('#inviteProfileMessage', error.message, false);
  }
});

$('#resellerProfileForm')?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  setMessage('#resellerProfileMessage', 'Salvando dados...');
  try {
    await postJson(appUrl('/api/public.php?action=save_reseller_profile'), {
      nome: form.elements.nome.value,
      whatsapp: form.elements.whatsapp.value,
    });
    setMessage('#resellerProfileMessage', 'Dados pessoais salvos.');
  } catch (error) {
    setMessage('#resellerProfileMessage', error.message, false);
  }
});

$('#copyPublicLinkBtn')?.addEventListener('click', async () => {
  if (!currentPublicLink) {
    setMessage('#ownerCopyMessage', 'Salve os dados para gerar o link antes de copiar.', false);
    return;
  }
  try {
    await navigator.clipboard.writeText(currentPublicLink);
    setMessage('#ownerCopyMessage', 'Link copiado.');
  } catch (error) {
    setMessage('#ownerCopyMessage', 'Não foi possível copiar automaticamente.', false);
  }
});

$('#resellerLogoutBtn')?.addEventListener('click', async () => {
  await fetch(appUrl('/api/public.php?action=logout'));
  location.href = appUrl('/membros/');
  location.reload();
});

const homeInviteBanner = $('#homeInviteBanner');
const homeInviteSummary = homeInviteBanner?.querySelector('.invite-banner__summary');
const homeInviteClose = homeInviteBanner?.querySelector('.invite-banner__close');
const setHomeInviteOpen = (open) => {
  homeInviteBanner?.classList.toggle('is-open', open);
  homeInviteSummary?.setAttribute('aria-expanded', String(open));
};
homeInviteSummary?.addEventListener('click', () => setHomeInviteOpen(!homeInviteBanner.classList.contains('is-open')));
homeInviteClose?.addEventListener('click', () => setHomeInviteOpen(false));

const stickyMobileCta = $('.sticky-mobile-cta');
const syncStickyMobileCta = () => {
  const receiveSection = $('#personalizar');
  const threshold = receiveSection
    ? receiveSection.offsetTop + receiveSection.offsetHeight - 24
    : 260;
  stickyMobileCta?.classList.toggle('is-visible', window.scrollY > threshold);
};
syncStickyMobileCta();
window.addEventListener('scroll', syncStickyMobileCta, { passive: true });
window.addEventListener('resize', syncStickyMobileCta);

loadTemplates();
loadReseller();
loadCheckout();
loadGlobalTexts();
setupTestimonialCarousel();

if (location.hash === '#comprovante' && $('#comprovante.checkout-modal')) {
  const rulesAccepted = sessionStorage.getItem('checkoutRulesAccepted') === '1';
  sessionStorage.removeItem('checkoutRulesAccepted');
  history.replaceState(null, '', `${location.pathname}${location.search}`);
  if (rulesAccepted) {
    setCheckoutModalOpen(true);
  } else {
    pendingCheckoutTarget = '#comprovante';
    setCheckoutRulesOpen(true);
  }
}
