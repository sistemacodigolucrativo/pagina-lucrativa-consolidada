<?php
declare(strict_types=1);

require dirname(__DIR__) . '/api/bootstrap.php';

$nameRaw = clean_text($_GET['nome'] ?? 'Seu Nome Aqui', 120);
$cityRaw = clean_text($_GET['cidade'] ?? 'Brasil', 80);
$modelRaw = clean_text($_GET['modelo'] ?? 'padrao', 40);

$templateMap = [
    'padrao' => 'classico',
    'premium' => 'dark',
    'direto' => 'whatsapp',
    'mobile' => 'mobile',
];

$template = $templateMap[$modelRaw] ?? 'classico';
$theme = $modelRaw === 'premium' ? '#facc15' : ($modelRaw === 'mobile' ? '#38bdf8' : '#16a34a');
$brand = htmlspecialchars('Página de ' . $nameRaw, ENT_QUOTES, 'UTF-8');
$title = htmlspecialchars('Página Lucrativa 2026 apresentada por ' . $nameRaw . '.', ENT_QUOTES, 'UTF-8');
$text = nl2br(htmlspecialchars('Esta é uma demonstração da página pública real. Ela organiza a apresentação da oportunidade, mostra o contato, explica o pagamento e direciona o visitante para o próximo passo com clareza.', ENT_QUOTES, 'UTF-8'));
$button = 'Ativar minha Página Lucrativa';
$price = 'R$ 10,00 demonstrativo';
$checkout = htmlspecialchars(app_base_path() . '/#comprovante', ENT_QUOTES, 'UTF-8');
$basePath = htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8');
$heroImage = $basePath . '/assets/visual-member-dashboard.svg';
$logo = $basePath . '/assets/icon.svg';
$pixType = 'PIX';
$pixKeyRaw = '';
$pixKey = 'PIX configurado após ativação';
$pixHolder = htmlspecialchars($nameRaw, ENT_QUOTES, 'UTF-8');
$pixCity = htmlspecialchars($cityRaw, ENT_QUOTES, 'UTF-8');
$pixInstructions = 'Esta prévia não solicita PIX real. Depois da compra, o dono da página configura seus próprios dados de pagamento.';
$testimonials = [
    'A página deixa tudo organizado em um link só, sem depender de mensagens soltas.',
    'O visitante entende a oportunidade, vê o contato e sabe qual é o próximo passo.',
    'A apresentação fica mais profissional para divulgar no WhatsApp, bio e grupos.',
];
$inviteNameRaw = $nameRaw;
$inviteName = htmlspecialchars($inviteNameRaw, ENT_QUOTES, 'UTF-8');
$inviteBio = 'Essa é a pessoa responsável por apresentar esta Página Lucrativa para você. Na página real, aqui aparecem a foto, descrição e contato configurados pelo dono da página.';
$invitePhotoRaw = '';
$invitePhoto = '';
$inviteWords = preg_split('/\s+/u', $inviteNameRaw) ?: [];
$inviteInitials = '';
foreach ($inviteWords as $word) {
    if ($word !== '') {
        $inviteInitials .= mb_strtoupper(mb_substr($word, 0, 1));
    }
    if (mb_strlen($inviteInitials) >= 2) {
        break;
    }
}
$inviteInitials = htmlspecialchars($inviteInitials !== '' ? $inviteInitials : 'SN', ENT_QUOTES, 'UTF-8');
$inviteWhatsapp = $checkout;
$inviteWhatsappLabel = 'Ativar para liberar WhatsApp real';

$isDemo = true;
$pageTitle = 'Demonstração | Página Lucrativa 2026';
$metaDescription = 'Prévia demonstrativa da Página Lucrativa 2026.';
$fixedNotice = 'Esta é uma prévia demonstrativa. A página real só é liberada após a ativação.';
$heroPrimaryHref = $checkout;
$heroPrimaryLabel = 'Ativar minha Página Lucrativa';
$heroSecondaryHref = $basePath . '/';
$heroSecondaryLabel = 'Voltar para a página principal';
$warningText = 'Demonstração protegida: PIX, WhatsApp, formulário e link público real só são liberados após a ativação.';
$heroCardText = 'Na página real, este card mostra sua oferta, seu visual escolhido e os dados configurados na Área de Membros.';
$proofItems = [
    ['title' => 'PIX na página', 'text' => 'dados de pagamento configurados depois'],
    ['title' => 'WhatsApp', 'text' => 'contato real liberado após ativação'],
    ['title' => 'Comprovante', 'text' => 'envio orientado na página'],
    ['title' => 'Link próprio', 'text' => 'apresentação organizada'],
];
$howSteps = [
    ['title' => 'Confira a oferta', 'text' => 'Na página real, o visitante entende a oportunidade e encontra as instruções principais.'],
    ['title' => 'Veja o PIX', 'text' => 'O PIX real aparece somente depois que o dono da página configura seus dados.'],
    ['title' => 'Entre em contato', 'text' => 'O botão de WhatsApp real fica ligado ao número configurado na Área de Membros.'],
];
$paymentTitle = 'Dados demonstrativos de pagamento.';
$copyPixButtonLabel = 'Ativar para liberar PIX real';
$stickyLabel = 'Ativar minha Página Lucrativa';
$stickyHref = $checkout;
$faqItems = [
    ['title' => 'Essa demo aceita pagamento?', 'text' => 'Não. Ela é apenas uma prévia visual com marca d\'água e dados fictícios.'],
    ['title' => 'Posso usar esta página como minha?', 'text' => 'Não. A página real só é liberada depois da ativação e configuração na Área de Membros.'],
    ['title' => 'O que muda depois da compra?', 'text' => 'Você configura nome, contato, PIX, modelo visual, texto e recebe seu link personalizado.'],
];

require dirname(__DIR__) . '/templates/public-page.php';
