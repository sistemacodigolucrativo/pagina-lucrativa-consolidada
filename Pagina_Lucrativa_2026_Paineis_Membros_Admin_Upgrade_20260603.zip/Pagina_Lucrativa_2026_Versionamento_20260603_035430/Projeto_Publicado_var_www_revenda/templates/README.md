# Templates

Os 10 modelos da Página Lucrativa 2026 são controlados pelo campo `template_escolhido`.

IDs disponíveis:

- `classico`
- `dark`
- `minimal`
- `whatsapp`
- `pix`
- `prova`
- `agressivo`
- `institucional`
- `mobile`
- `original`

Todos carregam os mesmos dados do banco. Cada modelo muda estrutura, ênfase visual, ordem dos blocos e comportamento mobile por CSS.
