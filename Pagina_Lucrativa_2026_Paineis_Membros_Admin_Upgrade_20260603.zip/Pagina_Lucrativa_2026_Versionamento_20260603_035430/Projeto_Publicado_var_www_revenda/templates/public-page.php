<?php
declare(strict_types=1);

$isDemo = !empty($isDemo);
$pageTitle = $pageTitle ?? ($brand . ' · Página Lucrativa');
$metaDescription = $metaDescription ?? ($brand . ' — página com oferta, pagamento via PIX e atendimento pelo WhatsApp.');
$bodyClass = trim((string) $template . ($isDemo ? ' demo-public' : ''));
$heroPrimaryHref = $heroPrimaryHref ?? '#pagamento';
$heroPrimaryLabel = $heroPrimaryLabel ?? 'Ver PIX e instruções';
$heroSecondaryHref = $heroSecondaryHref ?? $checkout;
$heroSecondaryLabel = $heroSecondaryLabel ?? 'Falar no WhatsApp';
$heroSecondaryTarget = $isDemo ? '' : ' target="_blank" rel="noreferrer"';
$warningText = $warningText ?? 'Após pagar, envie o comprovante pelo WhatsApp informado nesta página para conferência.';
$heroCardText = $heroCardText ?? 'Esta página reúne a oferta, o PIX e o WhatsApp de atendimento.';
$proofItems = $proofItems ?? [
    ['title' => 'PIX na página', 'text' => 'dados de pagamento visíveis'],
    ['title' => 'WhatsApp', 'text' => 'contato em um toque'],
    ['title' => 'Comprovante', 'text' => 'envio orientado'],
    ['title' => 'Link próprio', 'text' => 'apresentação organizada'],
];
$howSteps = $howSteps ?? [
    ['title' => 'Confira a oferta', 'text' => 'Veja valor, instruções e dados de pagamento desta página.'],
    ['title' => 'Pague via PIX', 'text' => 'Use a chave exibida abaixo com atenção ao recebedor.'],
    ['title' => 'Envie o comprovante', 'text' => 'Clique no WhatsApp e mande o comprovante para confirmação.'],
];
$paymentTitle = $paymentTitle ?? ('Dados para pagamento via ' . $pixType . '.');
$copyPixButtonLabel = $copyPixButtonLabel ?? 'Copiar chave PIX';
$stickyLabel = $stickyLabel ?? 'Enviar comprovante no WhatsApp';
$stickyHref = $stickyHref ?? $checkout;
$stickyTarget = $isDemo ? '' : ' target="_blank" rel="noreferrer"';
$faqItems = $faqItems ?? [
    ['title' => 'Como confirmo o pagamento?', 'text' => 'Depois do PIX, envie o comprovante pelo WhatsApp indicado nesta página.'],
    ['title' => 'Para onde envio o comprovante?', 'text' => 'Use o botão de WhatsApp desta página para falar diretamente com o responsável.'],
    ['title' => 'O que acontece depois?', 'text' => 'O pagamento será conferido e você receberá a orientação combinada nesta oferta.'],
];
$inviteWhatsappLabel = $inviteWhatsappLabel ?? ('Falar com ' . $inviteName . ' no WhatsApp');
$fixedNotice = $fixedNotice ?? 'Esta é uma prévia demonstrativa. A página real só é liberada após a ativação.';
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php if ($isDemo): ?>
  <meta name="robots" content="noindex, nofollow, noarchive">
  <meta name="googlebot" content="noindex, nofollow, noarchive">
  <?php endif; ?>
  <title><?= $pageTitle ?></title>
  <meta name="description" content="<?= $metaDescription ?>">
  <style>
    :root { --theme: <?= $theme ?>; --bg:#06101d; --text:#f8fafc; --muted:#cbd5e1; --panel:rgba(255,255,255,.07); --line:rgba(255,255,255,.14); }
    * { box-sizing:border-box; }
    html { scroll-behavior:smooth; }
    body { margin:0; font-family:Arial,Helvetica,sans-serif; background:radial-gradient(circle at 16% 0,color-mix(in srgb,var(--theme) 22%,transparent),transparent 28rem),#06101d; color:var(--text); }
    body.demo-public { -webkit-user-select:none; user-select:none; }
    body.demo-public img { -webkit-user-drag:none; user-select:none; }
    a { color:inherit; }
    .page { min-height:100vh; }
    .wrap { width:min(1080px,calc(100% - 2rem)); margin:0 auto; }
    .demo-fixed-notice { position:fixed; top:0; left:0; right:0; z-index:120; min-height:3.15rem; display:flex; align-items:center; justify-content:center; padding:.7rem 1rem; background:linear-gradient(90deg,#020617,#172554,#020617); color:#fff7ed; border-bottom:1px solid rgba(250,204,21,.32); text-align:center; font-weight:950; font-size:.9rem; }
    body.demo-public .page { padding-top:3.15rem; padding-bottom:5rem; position:relative; }
    .demo-watermark { position:fixed; inset:3.15rem 0 0; z-index:5; pointer-events:none; opacity:.12; background-image:repeating-linear-gradient(-32deg,transparent 0 5.5rem,rgba(255,255,255,.01) 5.5rem 9rem),repeating-linear-gradient(-32deg,transparent 0 9rem,rgba(250,204,21,.38) 9rem 9.12rem,transparent 9.12rem 16rem); }
    .demo-watermark::before, .demo-watermark::after { content:"DEMONSTRAÇÃO - NÃO É UMA PÁGINA ATIVA"; position:fixed; left:50%; top:44%; width:min(86vw,920px); transform:translate(-50%,-50%) rotate(-18deg); color:#fde68a; text-align:center; font-size:clamp(1.7rem,6vw,4.4rem); line-height:1.05; font-weight:950; letter-spacing:.08em; text-transform:uppercase; text-shadow:0 5px 24px rgba(0,0,0,.55); }
    .demo-watermark::after { top:72%; font-size:clamp(1.1rem,3.4vw,2.4rem); opacity:.65; }
    body.demo-public .page > * { position:relative; z-index:10; }
    .hero { min-height:92vh; display:grid; grid-template-columns:minmax(0,1.05fr) minmax(20rem,.95fr); gap:1.4rem; align-items:center; padding:3rem 0; }
    body.demo-public .hero { min-height:86vh; }
    .eyebrow { display:inline-flex; padding:.38rem .62rem; border-radius:999px; background:color-mix(in srgb,var(--theme) 16%,transparent); color:#dcfce7; border:1px solid color-mix(in srgb,var(--theme) 34%,transparent); font-size:.72rem; text-transform:uppercase; font-weight:900; }
    h1 { margin:.75rem 0 1rem; font-size:clamp(2.35rem,7vw,5.2rem); line-height:.93; letter-spacing:-.05em; }
    h2 { margin:.45rem 0 .8rem; font-size:clamp(1.75rem,4vw,3.2rem); line-height:1; letter-spacing:-.035em; }
    h3 { margin:.2rem 0 .5rem; }
    p { color:var(--muted); line-height:1.62; font-weight:750; }
    .lead { font-size:clamp(1.05rem,2vw,1.28rem); color:#e2e8f0; max-width:680px; }
    .hero-actions { display:flex; gap:.75rem; flex-wrap:wrap; margin-top:1.1rem; }
    .cta, .ghost { display:inline-flex; align-items:center; justify-content:center; min-height:3.2rem; padding:.95rem 1.2rem; border-radius:999px; font-weight:900; text-decoration:none; border:0; cursor:pointer; font-family:inherit; }
    .cta { background:var(--theme); color:#03130a; box-shadow:0 0 0 0 color-mix(in srgb,var(--theme) 40%,transparent); animation:pulse 2.4s infinite; }
    .ghost { border:1px solid var(--line); color:#fff; background:rgba(255,255,255,.05); }
    @keyframes pulse { 0%{box-shadow:0 0 0 0 color-mix(in srgb,var(--theme) 42%,transparent)} 70%{box-shadow:0 0 0 14px transparent} 100%{box-shadow:0 0 0 0 transparent} }
    .hero-card, .card, .pix-box, .proof { border:1px solid var(--line); background:var(--panel); border-radius:24px; box-shadow:0 26px 80px rgba(0,0,0,.34); }
    .hero-card { overflow:hidden; }
    .hero-card img { width:100%; min-height:300px; max-height:390px; object-fit:cover; display:block; background:color-mix(in srgb,var(--theme) 28%,#111827); }
    .hero-card-content { padding:1rem; display:grid; gap:.7rem; }
    .price { display:inline-flex; width:max-content; padding:.55rem .82rem; border-radius:999px; background:color-mix(in srgb,var(--theme) 18%,transparent); color:#fff; font-weight:900; }
    .proof-band { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:.75rem; margin:0 auto 2rem; }
    .proof-band article { padding:1rem; border:1px solid var(--line); border-radius:18px; background:rgba(255,255,255,.055); }
    .proof-band b { display:block; color:#fff; }
    .proof-band span { color:var(--muted); font-size:.88rem; font-weight:800; }
    .section { padding:3rem 0; }
    .grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:1rem; }
    .card { padding:1rem; }
    .card b { color:#fff; }
    .pix-box { padding:1rem; margin:1rem 0; background:linear-gradient(180deg,color-mix(in srgb,var(--theme) 15%,transparent),rgba(255,255,255,.05)); }
    .pix-box small { display:block; color:#bbf7d0; text-transform:uppercase; font-weight:900; }
    .pix-key { display:block; margin:.45rem 0; color:#fff; font-weight:900; word-break:break-word; font-size:1.05rem; }
    .meta { display:grid; gap:.35rem; color:#e2e8f0; font-weight:800; }
    .proofs { display:grid; gap:.75rem; margin-top:1rem; }
    body.demo-public .proofs { grid-template-columns:repeat(3,minmax(0,1fr)); }
    .proof { padding:.9rem; color:#f8fafc; }
    .proof small { display:block; margin-bottom:.35rem; color:#fde68a; font-weight:900; }
    .steps { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:1rem; }
    .section-image, .pix-visual { display:block; width:100%; border:1px solid var(--line); border-radius:24px; box-shadow:0 22px 64px rgba(0,0,0,.3); background:rgba(255,255,255,.04); }
    .section-image { margin:1rem 0 1.2rem; }
    .pix-visual { margin-bottom:1rem; }
    .step { padding:1rem; border-radius:20px; background:rgba(255,255,255,.055); border:1px solid var(--line); }
    .step span { display:inline-grid; place-items:center; width:2rem; height:2rem; border-radius:999px; background:var(--theme); color:#03130a; font-weight:900; }
    .warning { border:1px solid rgba(245,158,11,.35); background:rgba(245,158,11,.11); color:#fed7aa; border-radius:18px; padding:1rem; font-weight:850; }
    body.demo-public .warning { border-color:rgba(250,204,21,.4); background:rgba(250,204,21,.09); color:#fef3c7; }
    .quick-menu { position:fixed; top:1rem; right:1rem; z-index:80; }
    body.demo-public .quick-menu { top:4.1rem; z-index:90; }
    .quick-menu summary { width:3rem; height:3rem; display:grid; align-content:center; gap:.26rem; padding:.7rem; border:1px solid var(--line); border-radius:.8rem; background:rgba(6,16,29,.92); cursor:pointer; list-style:none; box-shadow:0 18px 48px rgba(0,0,0,.38); }
    .quick-menu summary::-webkit-details-marker { display:none; }
    .quick-menu summary span { display:block; height:.16rem; border-radius:999px; background:#fff; }
    .quick-menu-panel { position:absolute; top:calc(100% + .55rem); right:0; min-width:15rem; display:grid; gap:.32rem; padding:.65rem; border:1px solid var(--line); border-radius:.9rem; background:rgba(6,16,29,.96); }
    .quick-menu-panel a { padding:.75rem; border-radius:.62rem; text-decoration:none; font-weight:900; }
    .quick-menu-panel a:hover { background:color-mix(in srgb,var(--theme) 16%,transparent); }
    .sticky { position:fixed; left:.85rem; right:.85rem; bottom:.85rem; z-index:70; display:none; justify-content:center; align-items:center; min-height:3.15rem; border-radius:999px; background:var(--theme); color:#03130a; font-weight:900; text-decoration:none; box-shadow:0 20px 55px rgba(0,0,0,.38); }
    .invite-banner { max-width:1080px; margin:1rem auto 0; overflow:hidden; border:1px solid rgba(250,204,21,.26); border-radius:18px; background:rgba(255,255,255,.08); color:#fef3c7; box-shadow:0 18px 54px rgba(0,0,0,.28); backdrop-filter:blur(18px); }
    body.demo-public .invite-banner { background:linear-gradient(135deg,rgba(255,255,255,.1),rgba(255,255,255,.04)); }
    .invite-banner__summary { width:100%; display:flex; align-items:center; justify-content:center; gap:.7rem; border:0; background:transparent; color:#fde68a; cursor:pointer; font:inherit; font-weight:900; line-height:1.35; padding:.85rem 1rem; text-align:center; }
    .invite-banner__summary span { min-width:0; }
    .invite-banner__copy { display:grid; justify-items:center; gap:.18rem; }
    .invite-banner__line { display:block; }
    .invite-banner__action-text { display:inline-flex; width:fit-content; margin-top:.1rem; padding:.28rem .62rem; border:1px solid rgba(250,204,21,.26); border-radius:999px; color:#fde68a; background:rgba(250,204,21,.08); font-size:.82rem; font-weight:950; }
    .invite-banner__name { color:#facc15; word-break:break-word; }
    .invite-banner__profile { max-height:0; display:grid; grid-template-columns:auto minmax(0,1fr); gap:.9rem; align-items:center; padding:0 1rem; opacity:0; transform:translateY(-.35rem); transition:max-height 260ms ease, opacity 220ms ease, transform 220ms ease, padding 220ms ease; }
    .invite-banner.is-open .invite-banner__profile { max-height:22rem; padding:.15rem 1rem 1rem; opacity:1; transform:translateY(0); }
    .invite-banner__avatar { width:4.4rem; height:4.4rem; display:grid; place-items:center; overflow:hidden; border:2px solid rgba(250,204,21,.34); border-radius:999px; background:linear-gradient(135deg,#facc15,#854d0e); color:#111827; font-weight:950; box-shadow:0 14px 36px rgba(0,0,0,.28); }
    .invite-banner__avatar img { width:100%; height:100%; object-fit:cover; display:block; }
    .invite-banner__content { min-width:0; text-align:left; }
    .invite-banner__content strong { display:block; color:#fff7c2; line-height:1.35; }
    .invite-banner__bio { margin:.35rem 0 .7rem; color:#e7d9a3; font-size:.92rem; font-weight:800; line-height:1.45; }
    .invite-banner__actions { display:flex; flex-wrap:wrap; gap:.55rem; align-items:center; }
    .invite-banner__whatsapp, .invite-banner__close { min-height:2.35rem; display:inline-flex; align-items:center; justify-content:center; border-radius:999px; font-size:.84rem; font-weight:950; text-decoration:none; }
    .invite-banner__whatsapp { background:#facc15; color:#111827; padding:.65rem .85rem; }
    .invite-banner__close { border:0; background:transparent; color:#fde68a; cursor:pointer; padding:.45rem .3rem; }
    body.dark { --bg:#020617; }
    body.dark .hero-card { order:2; }
    body.minimal { background:#f8fafc; color:#111827; --text:#111827; --muted:#475569; --panel:#fff; --line:#dbe3ee; }
    body.minimal .hero-card img { display:none; }
    body.whatsapp .cta { background:#25d366; }
    body.pix .pix-box { background:var(--theme); color:#03130a; }
    body.pix .pix-box p, body.pix .pix-key, body.pix .meta, body.pix .pix-box small { color:#03130a; }
    body.prova .hero { grid-template-columns:1fr; }
    body.prova .proofs { grid-template-columns:repeat(2,minmax(0,1fr)); }
    body.agressivo h1 { text-transform:uppercase; }
    body.agressivo .cta { width:100%; font-size:1.08rem; }
    body.institucional { background:#f1f5f9; color:#0f172a; --text:#0f172a; --muted:#475569; --panel:#fff; --line:#d7e0ec; }
    body.mobile .hero { max-width:460px; grid-template-columns:1fr; }
    body.original .hero-card, body.original .card { border-radius:30px; }
    @media(max-width:900px){ .hero,.grid,.steps,.proof-band{grid-template-columns:1fr 1fr;} .hero{min-height:auto;} body.demo-public .proofs{grid-template-columns:1fr 1fr;} }
    @media(max-width:620px){ .hero,.grid,.steps,.proof-band,body.demo-public .proofs{grid-template-columns:1fr;} .hero-actions .cta,.hero-actions .ghost{width:100%;} .sticky{display:flex;} .page{padding-bottom:4.5rem;} .quick-menu{top:auto;bottom:4.7rem;} .quick-menu-panel{top:auto;bottom:calc(100% + .55rem);} .invite-banner{margin-top:.7rem;} .invite-banner__summary{display:grid;justify-items:center;padding:.82rem .75rem;} .invite-banner__profile{grid-template-columns:1fr;justify-items:center;text-align:center;} .invite-banner__content{text-align:center;} .invite-banner__actions{justify-content:center;} body.demo-public .demo-fixed-notice{font-size:.78rem;} body.demo-public .page{padding-top:3.6rem;} }
  </style>
</head>
<body class="<?= htmlspecialchars($bodyClass, ENT_QUOTES, 'UTF-8') ?>">
  <?php if ($isDemo): ?>
  <div class="demo-fixed-notice"><?= htmlspecialchars($fixedNotice, ENT_QUOTES, 'UTF-8') ?></div>
  <div class="demo-watermark" aria-hidden="true"></div>
  <?php endif; ?>
  <details class="quick-menu"><summary aria-label="Abrir menu"><span></span><span></span><span></span></summary><nav class="quick-menu-panel"><a href="#inicio">Início</a><a href="#como-funciona">Como funciona</a><a href="#pagamento">PIX</a><a href="#duvidas">Dúvidas</a><?php if ($isDemo): ?><a href="<?= $basePath ?>/">Voltar</a><?php endif; ?></nav></details>
  <main class="page" id="inicio">
    <section class="wrap invite-banner" id="inviteBanner">
      <button class="invite-banner__summary" type="button" aria-expanded="false" aria-controls="inviteProfile">
        <span class="invite-banner__copy">
          <span class="invite-banner__line">Convite exclusivo enviado por <b class="invite-banner__name"><?= $inviteName ?></b>.</span>
          <span class="invite-banner__line invite-banner__action-text">Toque aqui para conhecê-lo.</span>
        </span>
      </button>
      <div class="invite-banner__profile" id="inviteProfile">
        <div class="invite-banner__avatar" aria-hidden="true">
          <?php if ($invitePhotoRaw !== ''): ?><img src="<?= $invitePhoto ?>" alt=""><?php else: ?><?= $inviteInitials ?><?php endif; ?>
        </div>
        <div class="invite-banner__content">
          <strong>Você está vendo uma Página Lucrativa apresentada por <?= $inviteName ?>.</strong>
          <p class="invite-banner__bio"><?= $inviteBio ?></p>
          <div class="invite-banner__actions">
            <?php if ($inviteWhatsapp !== ''): ?><a class="invite-banner__whatsapp" href="<?= $inviteWhatsapp ?>"<?= $heroSecondaryTarget ?>><?= $inviteWhatsappLabel ?></a><?php endif; ?>
            <button type="button" class="invite-banner__close">Recolher</button>
          </div>
        </div>
      </div>
    </section>
    <section class="wrap hero">
      <div>
        <span class="eyebrow"><?= $brand ?></span>
        <h1><?= $title ?></h1>
        <p class="lead"><?= $text ?></p>
        <div class="hero-actions"><a class="cta" href="<?= $heroPrimaryHref ?>"><?= $heroPrimaryLabel ?></a><a class="ghost" href="<?= $heroSecondaryHref ?>"<?= $heroSecondaryTarget ?>><?= $heroSecondaryLabel ?></a></div>
        <div class="warning" style="margin-top:1rem"><?= $warningText ?></div>
      </div>
      <aside class="hero-card">
        <img src="<?= $heroImage ?>" alt="">
        <div class="hero-card-content">
          <img src="<?= $logo ?>" alt="" style="width:58px;height:58px;object-fit:cover;border-radius:14px;background:var(--theme);padding:6px">
          <span class="price"><?= $price ?></span>
          <b><?= $heroCardText ?></b>
        </div>
      </aside>
    </section>
    <section class="wrap proof-band"><?php foreach ($proofItems as $item): ?><article><b><?= htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') ?></b><span><?= htmlspecialchars($item['text'], ENT_QUOTES, 'UTF-8') ?></span></article><?php endforeach; ?></section>
    <section class="wrap section" id="como-funciona"><span class="eyebrow">Como funciona</span><h2>Três passos simples.</h2><img class="section-image" src="<?= $basePath ?>/assets/visual-flow-activation.svg" alt="Etapas de pagamento, comprovante e contato"><div class="steps"><?php foreach ($howSteps as $index => $step): ?><article class="step"><span><?= $index + 1 ?></span><h3><?= htmlspecialchars($step['title'], ENT_QUOTES, 'UTF-8') ?></h3><p><?= htmlspecialchars($step['text'], ENT_QUOTES, 'UTF-8') ?></p></article><?php endforeach; ?></div></section>
    <section class="wrap section" id="pagamento"><span class="eyebrow">Pagamento</span><h2><?= htmlspecialchars($paymentTitle, ENT_QUOTES, 'UTF-8') ?></h2><div class="pix-box"><img class="pix-visual" src="<?= $basePath ?>/assets/visual-pix-receipt.svg" alt="Pagamento PIX com envio de comprovante"><small>Chave PIX</small><span class="pix-key" id="pixKeyText"><?= $pixKey ?: 'Chave PIX ainda não cadastrada' ?></span><div class="meta"><span><strong>Recebedor:</strong> <?= $pixHolder ?></span><?php if ($pixCity): ?><span><strong>Cidade:</strong> <?= $pixCity ?></span><?php endif; ?><span><strong>Valor:</strong> <?= $price ?></span></div><p><?= $pixInstructions ?></p></div><div class="hero-actions"><button class="cta" id="copyPixPublicBtn" type="button" data-pix="<?= htmlspecialchars($pixKeyRaw, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($copyPixButtonLabel, ENT_QUOTES, 'UTF-8') ?></button><a class="ghost" href="<?= $checkout ?>"<?= $heroSecondaryTarget ?>><?= $button ?></a></div></section>
    <?php if ($testimonials): ?><section class="wrap section"><span class="eyebrow">Depoimentos</span><h2>Relatos e comentários.</h2><div class="proofs"><?php foreach (array_slice($testimonials, 0, 6) as $item): ?><div class="proof">“<?= htmlspecialchars($item, ENT_QUOTES, 'UTF-8') ?>”</div><?php endforeach; ?></div></section><?php endif; ?>
    <section class="wrap section" id="duvidas"><span class="eyebrow">Dúvidas rápidas</span><h2>Antes de pagar, confira.</h2><div class="grid"><?php foreach ($faqItems as $item): ?><article class="card"><b><?= htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') ?></b><p><?= htmlspecialchars($item['text'], ENT_QUOTES, 'UTF-8') ?></p></article><?php endforeach; ?></div></section>
  </main>
  <a class="sticky" href="<?= $stickyHref ?>"<?= $stickyTarget ?>><?= htmlspecialchars($stickyLabel, ENT_QUOTES, 'UTF-8') ?></a>
  <script>
    <?php if ($isDemo): ?>
    const blockDemoEvent = (event) => event.preventDefault();
    document.addEventListener('contextmenu', blockDemoEvent);
    document.addEventListener('copy', blockDemoEvent);
    document.addEventListener('cut', blockDemoEvent);
    document.addEventListener('selectstart', blockDemoEvent);
    document.addEventListener('dragstart', blockDemoEvent);
    document.getElementById('copyPixPublicBtn')?.addEventListener('click', function(){ window.location.href = '<?= $basePath ?>/#comprovante'; });
    <?php else: ?>
    document.getElementById('copyPixPublicBtn')?.addEventListener('click', async function(){try{await navigator.clipboard.writeText(this.dataset.pix || '');this.textContent='PIX copiado';}catch(e){this.textContent='Copie a chave acima';}});
    <?php endif; ?>
    const inviteBanner = document.getElementById('inviteBanner');
    const inviteSummary = inviteBanner?.querySelector('.invite-banner__summary');
    const inviteClose = inviteBanner?.querySelector('.invite-banner__close');
    const setInviteOpen = (open) => {
      inviteBanner?.classList.toggle('is-open', open);
      inviteSummary?.setAttribute('aria-expanded', String(open));
    };
    inviteSummary?.addEventListener('click', () => setInviteOpen(!inviteBanner.classList.contains('is-open')));
    inviteClose?.addEventListener('click', () => setInviteOpen(false));
  </script>
</body>
</html>
