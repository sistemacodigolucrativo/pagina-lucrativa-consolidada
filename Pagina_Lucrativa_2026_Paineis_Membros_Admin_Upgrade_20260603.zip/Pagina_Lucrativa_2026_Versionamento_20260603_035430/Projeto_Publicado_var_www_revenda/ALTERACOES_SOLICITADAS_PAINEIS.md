# ALTERAÇÕES SOLICITADAS — PAINEL DE MEMBROS E ADMIN

## Escopo

Upgrade concentrado nos painéis internos:

- Área de Membros
- Painel Administrativo

A página pública de vendas não foi reescrita neste ajuste.

---

## Área de Membros

### 1. Menu reorganizado por categorias

O menu da Área de Membros foi separado em grupos para deixar de parecer uma lista gigante.

Categorias aplicadas:

- Operação
  - Dashboard
  - Divulgação
  - Checklist

- Configuração da página
  - Minha Página
  - Aparência
  - Pagamento PIX
  - Perfil de Convite
  - Depoimentos

- Conta e ajuda
  - Tutoriais
  - Suporte
  - Conta
  - Regras

### 2. Dashboard mantido como tela inicial real

O Dashboard continua sendo a primeira tela do membro, sem formulário gigante.

Ele mantém foco em:

- status da página
- progresso de configuração
- link público
- ações rápidas
- prévia da página
- checklist resumido

### 3. Ações rápidas adicionadas ao Dashboard

Foram adicionados atalhos objetivos:

- Editar oferta
- Conferir PIX
- Ir para divulgação
- Preciso de ajuda

### 4. Nova tela de Suporte

Foi adicionada uma seção interna de suporte com orientações para:

- problema com acesso
- problema com link
- problema com PIX
- atendimento seguro

### 5. Separação de telas reforçada

Foi reforçada a regra visual/técnica para que apenas uma seção apareça por vez.

Objetivo: evitar o efeito de dashboard em página única gigante.

### 6. Placeholder de preço corrigido

O placeholder antigo “R$ 97,00” foi trocado por:

“Ex: R$ 10,00”

Motivo: evitar confusão com a oferta pública principal de R$ 10,00.

---

## Painel Administrativo

### 1. Dashboard administrativo criado

Foi criada uma aba inicial chamada Dashboard.

Ela aparece antes de Pedidos, Usuários, Pagamento PIX e Textos globais.

### 2. KPIs administrativos adicionados

O Dashboard do admin mostra:

- pedidos pendentes
- membros ativos
- páginas com link público
- status do PIX principal

### 3. Próximas ações adicionadas

Foram adicionados atalhos rápidos para:

- conferir pedidos
- ver membros
- configurar PIX
- editar textos globais

### 4. Saúde do sistema adicionada

O painel agora exibe verificações operacionais simples:

- se o PIX principal está configurado
- se existem pedidos pendentes
- quantidade de membros ativos
- quantidade de páginas com slug/link

### 5. Dashboard virou aba padrão do admin

Ao entrar no admin, a primeira visualização passa a ser o Dashboard, não mais “Usuários”.

---

## Arquivos alterados

- membros/index.html
- app.js
- style.css
- admin/index.html
- admin/admin.js
- admin/admin.css

---

## Observação operacional

Este pacote não deve ser usado para reescrever textos comerciais da landing page.

O foco foi deixar os painéis internos mais profissionais, mais organizados e menos parecidos com uma página única gigante.
