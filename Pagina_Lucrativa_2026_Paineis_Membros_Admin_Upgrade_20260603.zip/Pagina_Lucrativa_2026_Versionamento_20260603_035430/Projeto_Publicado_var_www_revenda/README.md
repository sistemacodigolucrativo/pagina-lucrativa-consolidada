# Página Lucrativa 2026

Projeto web centralizado em PHP + SQLite para Página Lucrativa 2026.

## Escopo atual

- Página pública persuasiva com foco em conversão mobile.
- Pagamento manual via PIX.
- Envio obrigatório de comprovante.
- Painel administrativo para aprovar, recusar e gerar chave.
- Área de Membros liberada por e-mail + chave.
- Configuração da Página Lucrativa do membro.
- Link personalizado por slug.
- Status ativo, suspenso e banido.
- Templates visuais para a página pública do membro.

## Observação

O projeto não deve ser vendido como renda garantida, dinheiro automático ou lucro certo. A promessa correta é estrutura pronta para criar e divulgar uma página própria com PIX, WhatsApp e link personalizado.

## Storage

Configure `REVENDA_STORAGE_DIR` fora da pasta pública para banco e comprovantes.

## URL pública

Configure `REVENDA_PUBLIC_URL` em produção para gerar links com o domínio correto.
