<?php
declare(strict_types=1);

require dirname(__DIR__) . '/api/bootstrap.php';

$pdo = db();
$path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
$slug = clean_text($_GET['slug'] ?? $_GET['r'] ?? '', 90);

if ($slug === '' && preg_match('#/(?:revenda/)?(?:p|r)/([^/]+)#', $path, $matches)) {
    $slug = clean_text($matches[1], 90);
}

if ($slug === '') {
    http_response_code(404);
    echo 'Link não encontrado.';
    exit;
}

$stmt = $pdo->prepare('
    SELECT r.*, c.nome_marca, c.pix, c.pix_tipo, c.pix_chave, c.pix_recebedor, c.pix_cidade, c.pix_instrucoes,
           c.comprovante_mensagem, c.dados_bancarios, c.checkout_url, c.preco, c.titulo_oferta,
           c.texto_oferta, c.texto_botao, c.depoimentos, c.cor_tema, c.logo, c.imagem_principal,
           c.public_name, c.profile_photo, c.profile_bio
    FROM revendedores r
    LEFT JOIN configuracoes_revendedor c ON c.user_id = r.id
    WHERE r.slug = ?
    LIMIT 1
');
$stmt->execute([$slug]);
$reseller = $stmt->fetch();

if (!$reseller || $reseller['status'] === 'banido') {
    http_response_code(403);
    echo '<!doctype html><meta charset="utf-8"><title>Link indisponível</title><style>body{font-family:Arial;background:#070b12;color:#fff;display:grid;place-items:center;min-height:100vh;text-align:center}</style><h1>Este link está indisponível.</h1>';
    exit;
}

if ($reseller['status'] === 'suspenso') {
    http_response_code(403);
    echo '<!doctype html><meta charset="utf-8"><title>Link indisponível</title><style>body{font-family:Arial;background:#070b12;color:#fff;display:grid;place-items:center;min-height:100vh;text-align:center}</style><h1>Este link está temporariamente indisponível.</h1>';
    exit;
}

if ($reseller['status'] !== 'ativo') {
    http_response_code(403);
    echo '<!doctype html><meta charset="utf-8"><title>Link pendente</title><style>body{font-family:Arial;background:#070b12;color:#fff;display:grid;place-items:center;min-height:100vh;text-align:center}</style><h1>Este link ainda não está ativo.</h1>';
    exit;
}

$template = $reseller['template_escolhido'] ?: 'classico';
if ($template === 'software') {
    $template = 'original';
}

$theme = preg_match('/^#[0-9a-fA-F]{6}$/', (string) $reseller['cor_tema']) ? $reseller['cor_tema'] : '#16a34a';
$brandRaw = (string) ($reseller['nome_marca'] ?: $reseller['nome']);
$brand = htmlspecialchars($brandRaw, ENT_QUOTES, 'UTF-8');
$title = htmlspecialchars($reseller['titulo_oferta'] ?: 'Conheça esta oferta agora', ENT_QUOTES, 'UTF-8');
$text = nl2br(htmlspecialchars($reseller['texto_oferta'] ?: 'Uma página simples e direta para apresentar a oferta, mostrar o PIX e facilitar o contato pelo WhatsApp.', ENT_QUOTES, 'UTF-8'));
$button = htmlspecialchars($reseller['texto_botao'] ?: 'Quero ativar agora', ENT_QUOTES, 'UTF-8');
$price = htmlspecialchars($reseller['preco'] ?: 'Consulte o valor', ENT_QUOTES, 'UTF-8');
$whatsappNumber = preg_replace('/\D+/', '', (string) $reseller['whatsapp']);
$receiptMessage = $reseller['comprovante_mensagem'] ?: 'Olá, vi sua página e quero enviar o comprovante.';
$checkout = htmlspecialchars($whatsappNumber ? ('https://wa.me/' . $whatsappNumber . '?text=' . rawurlencode($receiptMessage)) : '#', ENT_QUOTES, 'UTF-8');
$defaultIcon = app_base_path() . '/assets/icon.svg';
$defaultHero = app_base_path() . '/assets/visual-member-dashboard.svg';
$heroImage = htmlspecialchars($reseller['imagem_principal'] ?: $defaultHero, ENT_QUOTES, 'UTF-8');
$logo = htmlspecialchars($reseller['logo'] ?: $defaultIcon, ENT_QUOTES, 'UTF-8');
$pixType = htmlspecialchars($reseller['pix_tipo'] ?: 'PIX', ENT_QUOTES, 'UTF-8');
$pixKeyRaw = (string) ($reseller['pix_chave'] ?: $reseller['pix'] ?: '');
$pixKey = htmlspecialchars($pixKeyRaw, ENT_QUOTES, 'UTF-8');
$pixHolder = htmlspecialchars($reseller['pix_recebedor'] ?: $brandRaw, ENT_QUOTES, 'UTF-8');
$pixCity = htmlspecialchars($reseller['pix_cidade'] ?: '', ENT_QUOTES, 'UTF-8');
$pixInstructions = nl2br(htmlspecialchars($reseller['pix_instrucoes'] ?: 'Faça o pagamento via PIX e envie o comprovante pelo WhatsApp para confirmar seu pedido.', ENT_QUOTES, 'UTF-8'));
$testimonials = array_filter(array_map('trim', preg_split('/\R+/', (string) ($reseller['depoimentos'] ?? '')) ?: []));
$basePath = htmlspecialchars(app_base_path(), ENT_QUOTES, 'UTF-8');
$inviteNameRaw = clean_text($reseller['public_name'] ?: $reseller['nome_marca'] ?: $reseller['nome'], 120);
$inviteName = htmlspecialchars($inviteNameRaw, ENT_QUOTES, 'UTF-8');
$inviteBio = htmlspecialchars(clean_text($reseller['profile_bio'] ?: 'Essa é a pessoa responsável por apresentar esta Página Lucrativa para você.', 180), ENT_QUOTES, 'UTF-8');
$invitePhotoRaw = clean_text($reseller['profile_photo'] ?: '', 500);
$invitePhoto = htmlspecialchars($invitePhotoRaw, ENT_QUOTES, 'UTF-8');
$inviteWords = preg_split('/\s+/u', $inviteNameRaw) ?: [];
$inviteInitials = '';
foreach ($inviteWords as $word) {
    if ($word !== '') {
        $inviteInitials .= mb_strtoupper(mb_substr($word, 0, 1));
    }
    if (mb_strlen($inviteInitials) >= 2) {
        break;
    }
}
$inviteInitials = htmlspecialchars($inviteInitials !== '' ? $inviteInitials : 'PL', ENT_QUOTES, 'UTF-8');
$inviteWhatsapp = $whatsappNumber ? htmlspecialchars('https://wa.me/' . $whatsappNumber . '?text=' . rawurlencode('Olá, recebi seu convite da Página Lucrativa e quero saber mais.'), ENT_QUOTES, 'UTF-8') : '';
$inviteWhatsappLabel = 'Falar com ' . $inviteName . ' no WhatsApp';

$pageTitle = $brand . ' · Página Lucrativa';
$metaDescription = $brand . ' — página com oferta, pagamento via PIX e atendimento pelo WhatsApp.';

require dirname(__DIR__) . '/templates/public-page.php';
